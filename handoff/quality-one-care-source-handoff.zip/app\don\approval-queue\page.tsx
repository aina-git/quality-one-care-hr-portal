import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { MessageComposer } from "@/components/MessageComposer";
import { OperationalPulse } from "@/components/OperationalPulse";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { summarizeChecklist } from "@/services/verification/verificationService";

function label(value: string | null | undefined) {
  if (!value) return "-";
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

export default async function DonApprovalQueuePage() {
  const user = await requireRole(["admin", "super_admin_hr", "don_approver", "executive_view_only"]);
  const thisMonth = new Date();
  thisMonth.setDate(1);
  thisMonth.setHours(0, 0, 0, 0);
  const [ready, returned, approvedThisMonth] = await Promise.all([
    prisma.finalVerificationChecklist.findMany({
      where: { status: "ready_for_don_review" },
      include: {
        reviewedByUser: true,
        application: { include: { applicantProfile: { include: { user: true } }, licenses: true } },
        items: true
      },
      orderBy: { submittedToDonAt: "asc" }
    }),
    prisma.finalVerificationChecklist.count({ where: { status: "returned_for_correction" } }),
    prisma.finalVerificationChecklist.count({ where: { status: "approved_by_don", approvedAt: { gte: thisMonth } } })
  ]);
  const canMessage = ["admin", "super_admin_hr", "don_approver"].includes(user.role);

  return (
    <DashboardShell user={user} nav={[
      { href: "/hr/dashboard", label: "Dashboard" },
      { href: "/don/approval-queue", label: "DON Approval Queue" },
      { href: "/hr/verification", label: "Verification Records" }
    ]}>
      <div className="grid gap-6">
        <section className="rounded-xl border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">DON Approval Queue</p>
          <h1 className="mt-2 text-3xl font-semibold">Final Approval for Hire</h1>
        </section>
        <div className="grid gap-4 sm:grid-cols-3">
          <OperationalPulse label="Ready for Final Approval" value={ready.length} icon="check" color="green" />
          <OperationalPulse label="Returned for Correction" value={returned} icon="alert" color="orange" />
          <OperationalPulse label="Approved This Month" value={approvedThisMonth} icon="care" color="teal" />
        </div>
        <Card>
          <CardHeader><CardTitle>Ready for DON Review</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applicant</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>HR Verification Status</TableHead>
                  <TableHead>Submitted By HR</TableHead>
                  <TableHead>Submitted Date</TableHead>
                  <TableHead>Readiness</TableHead>
                  <TableHead>Blocking Concerns</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ready.map((checklist) => {
                  const summary = summarizeChecklist(checklist);
                  return (
                    <TableRow key={checklist.id}>
                      <TableCell>{checklist.application.applicantProfile.user.name ?? checklist.application.applicantProfile.user.email}</TableCell>
                      <TableCell>{checklist.application.desiredRole ?? "-"}</TableCell>
                      <TableCell>{label(checklist.status)}</TableCell>
                      <TableCell>{checklist.reviewedByUser ? checklist.reviewedByUser.name ?? checklist.reviewedByUser.email : "System/HR"}</TableCell>
                      <TableCell>{checklist.submittedToDonAt?.toLocaleString() ?? "-"}</TableCell>
                      <TableCell>{summary.completionPercentage}%</TableCell>
                      <TableCell>
                        {summary.criticalBlockers.length ? summary.criticalBlockers.map((item) => item.title).join(", ") : "None"}
                      </TableCell>
                      <TableCell>
                        <div className="grid min-w-48 gap-2">
                          <Button asChild size="sm"><Link href={`/don/final-approval/${checklist.applicationId}`}>Final Approval Page</Link></Button>
                          <Button asChild size="sm" variant="outline"><Link href={`/don/final-approval/${checklist.applicationId}/print`}>Printable Report</Link></Button>
                          <Button asChild size="sm" variant="outline"><Link href={`/hr/applications/${checklist.applicationId}/verification`}>Verification Record</Link></Button>
                          {canMessage ? (
                            <details className="rounded-md border bg-slate-50 p-2">
                              <summary className="cursor-pointer text-xs font-medium">Send Message</summary>
                              <div className="mt-2"><MessageComposer applicationId={checklist.applicationId} compact /></div>
                            </details>
                          ) : <span className="text-xs text-muted-foreground">Read only</span>}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {!ready.length ? <TableRow><TableCell colSpan={8} className="text-muted-foreground">No applications are ready for DON final approval.</TableCell></TableRow> : null}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
