import { DashboardShell } from "@/components/DashboardShell";
import { EmployeeOnboardingTaskActions } from "@/components/EmployeeOnboardingTaskActions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function label(value: string) {
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

export default async function ApplicantOnboardingPage() {
  const user = await requireRole(["applicant"]);
  const application = await prisma.application.findFirst({
    where: { applicantProfile: { userId: user.id } },
    orderBy: { updatedAt: "desc" },
    include: {
      employeeOnboarding: { include: { tasks: { orderBy: { createdAt: "asc" } } } },
      trainingRecommendations: { orderBy: [{ priority: "desc" }, { createdAt: "asc" }] }
    }
  });
  const onboarding = application?.employeeOnboarding;
  const complete = onboarding?.tasks.filter((task) => task.status !== "pending").length ?? 0;

  return (
    <DashboardShell user={user} nav={[{ href: "/applicant/dashboard", label: "Dashboard" }, { href: "/applicant/application", label: "Application" }, { href: "/applicant/intake-review", label: "Intake Review" }, { href: "/applicant/messages", label: "Messages" }, { href: "/applicant/onboarding", label: "Onboarding" }]}>
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Applicant Onboarding</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Onboarding Tasks</h1>
        </section>

        {!onboarding ? (
          <Card><CardContent className="p-6 text-sm text-muted-foreground">Onboarding tasks will appear after final DON approval.</CardContent></Card>
        ) : (
          <>
            <Card>
              <CardHeader><CardTitle>Progress</CardTitle></CardHeader>
              <CardContent className="grid gap-3 text-sm">
                <p>{complete} of {onboarding.tasks.length} tasks complete or waived.</p>
                <div className="h-2 rounded-full bg-slate-100">
                  <div className="h-2 rounded-full bg-orange-500" style={{ width: `${onboarding.tasks.length ? Math.round((complete / onboarding.tasks.length) * 100) : 0}%` }} />
                </div>
              </CardContent>
            </Card>
            <div className="grid gap-3">
              {onboarding.tasks.map((task) => (
                <Card key={task.id}>
                  <CardContent className="grid gap-3 p-4 text-sm md:grid-cols-[minmax(0,1fr)_auto]">
                    <div>
                      <p className="font-medium">{task.title}</p>
                      <p className="text-muted-foreground">{task.description}</p>
                      <p className="mt-1 text-xs text-orange-700">{label(task.status)}{task.dueDate ? ` - due ${task.dueDate.toLocaleDateString()}` : ""}</p>
                    </div>
                    <EmployeeOnboardingTaskActions taskId={task.id} currentStatus={task.status} mode="applicant" />
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}

        <Card>
          <CardHeader><CardTitle>Recommended Training</CardTitle></CardHeader>
          <CardContent className="grid gap-2 text-sm">
            {application?.trainingRecommendations.length ? application.trainingRecommendations.map((item) => (
              <div key={item.id} className="rounded-md border bg-slate-50 p-3">
                <p className="font-medium">{item.trainingTitle}</p>
                <p className="text-muted-foreground">{item.reason}</p>
                <p className="mt-1 text-xs uppercase text-orange-700">{item.priority} priority - {label(item.status)}</p>
              </div>
            )) : <p className="text-muted-foreground">Training recommendations will appear after final approval.</p>}
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
