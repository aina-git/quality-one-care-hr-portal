import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { MetricCard } from "@/components/MetricCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { logAction } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { getAdminAnalyticsData } from "@/services/analytics/analyticsService";

const adminNav = [
  { href: "/admin/dashboard", label: "Dashboard" },
  { href: "/admin/analytics", label: "Analytics" },
  { href: "/admin/system-health", label: "System Health" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/audit", label: "Audit" }
];

export default async function AdminAnalyticsPage() {
  const user = await requireRole(["admin", "super_admin_hr", "executive_view_only"]);
  const analytics = await getAdminAnalyticsData();
  await logAction(user.id, "admin_analytics_viewed", "dashboard", "admin_analytics");

  return (
    <DashboardShell user={user} nav={adminNav}>
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Operational Analytics</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Application and HR performance</h1>
        </section>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Total Applications" value={analytics.totals.applications} />
          <MetricCard label="Submitted to Interview" value={`${analytics.totals.submittedToInterviewRate}%`} />
          <MetricCard label="Interview to Approved" value={`${analytics.totals.interviewToApprovedRate}%`} />
          <MetricCard label="Average Time to Decision" value={`${analytics.totals.averageTimeToDecisionDays} days`} />
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Most Common Rejection Reasons</CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link href="/api/admin/export?type=audit_logs">Export Audit Logs</Link>
              </Button>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm">
              {analytics.rejectionReasons.length ? analytics.rejectionReasons.map((reason) => (
                <div key={reason.reason} className="rounded-md border bg-slate-50 p-3">
                  <p className="font-medium">{reason.reason}</p>
                  <p className="text-muted-foreground">{reason.count} decision(s)</p>
                </div>
              )) : <p className="text-muted-foreground">No rejection decisions have been recorded yet.</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>License Expiration Trends</CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link href="/api/admin/export?type=license_status">Export License Status</Link>
              </Button>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2 text-sm">
              <div className="rounded-md border bg-slate-50 p-3"><p className="font-medium">Expired</p><p>{analytics.licenseTrends.expired}</p></div>
              <div className="rounded-md border bg-slate-50 p-3"><p className="font-medium">Within 7 Days</p><p>{analytics.licenseTrends.expiring7Days}</p></div>
              <div className="rounded-md border bg-slate-50 p-3"><p className="font-medium">Within 30 Days</p><p>{analytics.licenseTrends.expiring30Days}</p></div>
              <div className="rounded-md border bg-slate-50 p-3"><p className="font-medium">Active Beyond 30 Days</p><p>{analytics.licenseTrends.active}</p></div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>HR Performance Metrics</CardTitle>
            <Button asChild variant="outline" size="sm">
              <Link href="/api/admin/export?type=applications">Export Applications</Link>
            </Button>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Reviews Completed</TableHead>
                  <TableHead>Average Review Time</TableHead>
                  <TableHead>Decisions Made</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analytics.hrPerformance.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell>{entry.name}</TableCell>
                    <TableCell className="capitalize">{entry.role}</TableCell>
                    <TableCell>{entry.reviewsCompleted}</TableCell>
                    <TableCell>{entry.averageReviewHours} hours</TableCell>
                    <TableCell>{entry.decisionsMade}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
