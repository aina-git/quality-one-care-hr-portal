import fs from "node:fs/promises";
import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { logAction } from "@/lib/audit";
import { sanitizeText } from "@/lib/security";
import { getAuthorizedDocument } from "@/services/authorization/accessService";
import { handleApiError } from "@/services/monitoring/errorService";
import { resolveDocumentPath, verifySignedDocumentToken } from "@/services/storage/storageService";

export const runtime = "nodejs";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Authentication required." }, { status: 401 });
  }

  const { id } = await params;
  const token = new URL(request.url).searchParams.get("token") ?? "";

  try {
    const document = await getAuthorizedDocument(sanitizeText(id, 80), session.id, session.role);
    if (!verifySignedDocumentToken(document.id, session.id, token)) {
      return NextResponse.json({ error: "Document access token is invalid or expired." }, { status: 403 });
    }

    const absolutePath = await resolveDocumentPath(document.storageKey);
    const file = await fs.readFile(absolutePath);
    await logAction(session.id, "document_accessed", "uploaded_document", document.id, { storageKey: document.storageKey });
    return new NextResponse(file, {
      status: 200,
      headers: {
        "Content-Type": document.mimeType ?? "application/octet-stream",
        "Content-Disposition": `inline; filename="${document.fileName}"`,
        "Cache-Control": "private, no-store"
      }
    });
  } catch (error) {
    return handleApiError(error, {
      scope: "documents.read",
      action: "api_failure",
      userId: session.id,
      entityType: "uploaded_document",
      entityId: id,
      fallbackMessage: "Document could not be opened."
    });
  }
}
