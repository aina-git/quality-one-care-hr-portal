import { CalendarEventForm } from "@/components/CalendarEventForm";
import { DashboardShell } from "@/components/DashboardShell";
import { OperationalPulse } from "@/components/OperationalPulse";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

function eventColor(type: string) {
  if (type === "interview") return "bg-orange-100 text-orange-800";
  if (type === "training") return "bg-purple-100 text-purple-800";
  if (type === "onboarding") return "bg-teal-100 text-teal-800";
  if (type.includes("followup")) return "bg-red-100 text-red-800";
  return "bg-blue-100 text-blue-800";
}

export default async function CalendarPage({ searchParams }: { searchParams?: Promise<{ view?: string }> }) {
  const user = await requireAuth();
  const params = searchParams ? await searchParams : {};
  const view = ["month", "week", "day", "list"].includes(params.view ?? "") ? params.view! : "week";
  const where: Prisma.CalendarEventWhereInput = {};
  if (user.role === "applicant") {
    where.OR = [{ relatedApplicantUserId: user.id }, { visibility: "applicant_visible", relatedApplication: { applicantProfile: { userId: user.id } } }];
  } else if (user.role === "scheduler_limited") {
    where.relatedApplication = { status: "approved" };
  } else if (user.role === "executive_view_only") {
    where.visibility = { in: ["executive_visible", "applicant_visible"] };
  } else if (user.role === "don_approver") {
    where.eventType = { in: ["meeting", "reminder", "document_followup", "license_followup", "hr_task"] };
  }
  const events = await prisma.calendarEvent.findMany({
    where,
    include: { relatedApplication: { include: { applicantProfile: { include: { user: true } } } }, assignedToUser: true },
    orderBy: { startDateTime: "asc" },
    take: 100
  });
  const today = events.filter((event) => event.startDateTime.toDateString() === new Date().toDateString()).length;
  const upcoming = events.filter((event) => event.startDateTime >= new Date()).length;
  const canCreate = !["executive_view_only", "don_approver"].includes(user.role);

  return (
    <DashboardShell user={user} nav={[]}>
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Calendar</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Operational schedule</h1>
          <div className="mt-4 flex flex-wrap gap-2 text-sm">
            {["month", "week", "day", "list"].map((item) => <a key={item} href={`/calendar?view=${item}`} className={`rounded-full border px-3 py-1 capitalize ${view === item ? "bg-orange-600 text-white" : "bg-white"}`}>{item}</a>)}
          </div>
        </section>
        <div className="grid gap-4 sm:grid-cols-3">
          <OperationalPulse label="Events Today" value={today} icon="calendar" color="blue" />
          <OperationalPulse label="Upcoming" value={upcoming} icon="clock" color="teal" />
          <OperationalPulse label="Applicant-visible" value={events.filter((event) => event.visibility === "applicant_visible").length} icon="message" color="green" />
        </div>
        {canCreate ? <Card><CardHeader><CardTitle>Create Event</CardTitle></CardHeader><CardContent><CalendarEventForm /></CardContent></Card> : null}
        <Card>
          <CardHeader><CardTitle>{view[0].toUpperCase() + view.slice(1)} View</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader><TableRow><TableHead>Event</TableHead><TableHead>Type</TableHead><TableHead>Time</TableHead><TableHead>Applicant</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
              <TableBody>
                {events.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell><p className="font-medium">{event.title}</p><p className="text-xs text-muted-foreground">{event.location ?? event.meetingLink ?? event.description}</p></TableCell>
                    <TableCell><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${eventColor(event.eventType)}`}>{event.eventType.replace(/_/g, " ")}</span></TableCell>
                    <TableCell>{event.startDateTime.toLocaleString()}<br /><span className="text-xs text-muted-foreground">to {event.endDateTime.toLocaleString()}</span></TableCell>
                    <TableCell>{event.relatedApplication?.applicantProfile.user.name ?? event.relatedApplication?.applicantProfile.user.email ?? "-"}</TableCell>
                    <TableCell className="capitalize">{event.status.replace(/_/g, " ")}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
