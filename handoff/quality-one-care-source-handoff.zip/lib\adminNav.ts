export const adminNav = [
  { href: "/admin/dashboard", label: "Dashboard" },
  { href: "/admin/analytics", label: "Analytics" },
  { href: "/admin/system-health", label: "System Health" },
  { href: "/admin/analysis-settings", label: "Analysis Settings" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/audit", label: "Audit" },
  { href: "/admin/notifications", label: "Notifications" },
  { href: "/admin/calendar", label: "Calendar" },
  { href: "/admin/tasks", label: "Tasks" },
  { href: "/admin/applications", label: "Applications" },
  { href: "/admin/verification-queue", label: "Verification Queue" },
  { href: "/admin/hr-review-queue", label: "HR Review Queue" },
  { href: "/admin/don-approval-queue", label: "DON Approval Queue" }
];
