import Link from "next/link";
import { redirect } from "next/navigation";
import { ApplicantProgressTimeline } from "@/components/ApplicantProgressTimeline";
import { ApplicationWorkflowControls } from "@/components/ApplicationWorkflowControls";
import { DashboardShell } from "@/components/DashboardShell";
import { HRDecisionPanel } from "@/components/HRDecisionPanel";
import { HrMissingInformationEditor } from "@/components/HrMissingInformationEditor";
import { HRNoteForm } from "@/components/HRNoteForm";
import { InterviewScheduler } from "@/components/InterviewScheduler";
import { OnboardingItemActions } from "@/components/OnboardingItemActions";
import { RecommendationBadge, RiskBadge } from "@/components/ReviewBadges";
import { RunReviewButton } from "@/components/RunReviewButton";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { logAction } from "@/lib/audit";
import { prisma } from "@/lib/prisma";
import { getApplicationProgress } from "@/services/applicantProgressService";
import { startHrReviewWorkflow } from "@/services/workflow/hrReviewQueueService";

function asList(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String) : [];
}

function ReviewJsonCard({ title, data }: { title: string; data: unknown }) {
  return (
    <Card>
      <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
      <CardContent>
        <pre className="whitespace-pre-wrap rounded-md bg-slate-50 p-3 text-sm text-slate-700">{JSON.stringify(data ?? {}, null, 2)}</pre>
      </CardContent>
    </Card>
  );
}

export default async function HrApplicationReviewPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireRole(["hr", "admin", "super_admin_hr", "don_approver", "executive_view_only"]);
  const { id } = await params;
  let application = await prisma.application.findUnique({
    where: { id },
    include: {
      applicantProfile: { include: { user: true } },
      aiReviewReports: { orderBy: { createdAt: "desc" }, take: 1, include: { findings: true } },
      decisions: { orderBy: { createdAt: "desc" }, include: { createdBy: true } },
      statusHistory: { orderBy: { createdAt: "desc" }, include: { changedBy: true } },
      hrNotes: { orderBy: { createdAt: "desc" }, include: { createdBy: true } },
      interviewRecords: { orderBy: { createdAt: "desc" }, include: { createdBy: true } },
      onboardingChecklist: { include: { items: { orderBy: { createdAt: "asc" } } } },
      licenseAlerts: { where: { resolved: false }, orderBy: { createdAt: "desc" } },
      validationIssues: { where: { resolved: false }, orderBy: { createdAt: "desc" } }
    }
  });

  if (!application) redirect("/hr/applications");
  if (application.status === "hr_review_pending" && ["hr", "admin", "super_admin_hr"].includes(user.role)) {
    await startHrReviewWorkflow(application.id, user.id);
    application = await prisma.application.findUnique({
      where: { id },
      include: {
        applicantProfile: { include: { user: true } },
        aiReviewReports: { orderBy: { createdAt: "desc" }, take: 1, include: { findings: true } },
        decisions: { orderBy: { createdAt: "desc" }, include: { createdBy: true } },
        statusHistory: { orderBy: { createdAt: "desc" }, include: { changedBy: true } },
        hrNotes: { orderBy: { createdAt: "desc" }, include: { createdBy: true } },
        interviewRecords: { orderBy: { createdAt: "desc" }, include: { createdBy: true } },
        onboardingChecklist: { include: { items: { orderBy: { createdAt: "asc" } } } },
        licenseAlerts: { where: { resolved: false }, orderBy: { createdAt: "desc" } },
        validationIssues: { where: { resolved: false }, orderBy: { createdAt: "desc" } }
      }
    });
    if (!application) redirect("/hr/applications");
  }
  await logAction(user.id, "hr_review_viewed", "application", application.id);
  const report = application.aiReviewReports[0];
  const strengths = asList(report?.strengthsJson);
  const concerns = asList(report?.concernsJson);
  const actionItems = asList(report?.hrActionItemsJson);
  const activeInterview = application.interviewRecords.find((interview) => interview.status !== "cancelled");
  const onboardingItems = application.onboardingChecklist?.items ?? [];
  const completedOnboardingItems = onboardingItems.filter((item) => item.status !== "pending").length;
  const canEditHrWorkflow = ["hr", "admin", "super_admin_hr"].includes(user.role);
  const progress = await getApplicationProgress(application.id);

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/hr/dashboard", label: "Dashboard" },
        { href: "/hr/applications", label: "Applications" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">HR Review Report</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">{application.applicantProfile.user.name ?? application.applicantProfile.user.email}</h1>
          <div className="mt-4 flex flex-wrap gap-2">
            <StatusBadge status={application.status} />
            {report && <RiskBadge risk={report.overallRiskLevel} />}
            {report && <RecommendationBadge recommendation={report.recommendation} />}
          </div>
          <p className="mt-4 rounded-md border border-orange-200 bg-orange-50 p-3 text-sm text-orange-800">
            Machine-learning-assisted review. Final approval must be completed by the authorized DON reviewer.
          </p>
          <div className="mt-5">
            {canEditHrWorkflow ? <RunReviewButton applicationId={application.id} hasReport={Boolean(report)} /> : null}
          </div>
          <div className="mt-3">
            <Button asChild variant="outline">
              <Link href={`/hr/applications/${application.id}/verification`}>Open Final Verification</Link>
            </Button>
          </div>
        </section>

        {progress ? (
          <Card>
            <CardHeader><CardTitle>Applicant Progress Monitor</CardTitle></CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-3 md:grid-cols-3">
                <div className="rounded-xl border border-purple-200 bg-purple-50 p-3 text-sm text-purple-900">
                  <p className="font-semibold">Current stage</p>
                  <p>{progress.activeStage.label}</p>
                </div>
                <div className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
                  <p className="font-semibold">Responsible staff</p>
                  <p>{progress.responsibleStaff}</p>
                </div>
                <div className="rounded-xl border border-orange-200 bg-orange-50 p-3 text-sm text-orange-900">
                  <p className="font-semibold">Next action</p>
                  <p>{progress.nextActionRequired}</p>
                </div>
              </div>
              <ApplicantProgressTimeline stages={progress.stages} compact />
            </CardContent>
          </Card>
        ) : null}

        <Card>
          <CardHeader><CardTitle>Review Status</CardTitle></CardHeader>
          <CardContent className="grid gap-3 text-sm">
            <p>Status: <span className="font-medium capitalize">{report?.status ?? "not run"}</span></p>
            <p>Generated by: <span className="font-medium">{report?.generatedBy ?? "Not generated"}</span></p>
            <p>{report?.summary ?? "No review report has been generated yet."}</p>
          </CardContent>
        </Card>

        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <Card>
            <CardHeader><CardTitle>Workflow Controls</CardTitle></CardHeader>
            <CardContent className="grid gap-5">
              {application.decisions.length > 0 && (
                <div className="rounded-md border bg-slate-50 p-3 text-sm">
                  <p className="font-medium capitalize">Latest: {application.decisions[0].action.replace(/_/g, " ")}</p>
                  <p className="mt-1 text-muted-foreground">
                    {application.decisions[0].fromStatus.replace(/_/g, " ")} to {application.decisions[0].toStatus.replace(/_/g, " ")}
                  </p>
                  <p className="mt-2">{application.decisions[0].note}</p>
                </div>
              )}
              {canEditHrWorkflow ? <HRDecisionPanel applicationId={application.id} /> : <p className="text-sm text-muted-foreground">Read-only access.</p>}
              {canEditHrWorkflow ? <ApplicationWorkflowControls applicationId={application.id} currentStatus={application.status} /> : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Internal HR Notes</CardTitle></CardHeader>
            <CardContent className="grid gap-4">
              {canEditHrWorkflow ? <HRNoteForm applicationId={application.id} /> : null}
              <div className="grid gap-2 text-sm">
                {application.hrNotes.length ? application.hrNotes.map((note) => (
                  <div key={note.id} className="rounded-md border bg-slate-50 p-3">
                    <p>{note.note}</p>
                    <p className="mt-2 text-xs text-muted-foreground">
                      {note.createdBy.name ?? note.createdBy.email} on {note.createdAt.toLocaleDateString()}
                    </p>
                  </div>
                )) : <p className="text-muted-foreground">No internal notes yet. These notes are not visible to applicants.</p>}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Missing Information and Section Editing</CardTitle></CardHeader>
          <CardContent>
            {canEditHrWorkflow ? (
              <HrMissingInformationEditor applicationId={application.id} issues={application.validationIssues} />
            ) : (
              <div className="grid gap-2 text-sm">
                {application.validationIssues.map((issue) => (
                  <div key={issue.id} className="rounded-md border bg-slate-50 p-3">
                    <p className="font-medium">{issue.section}{issue.fieldKey ? ` - ${issue.fieldKey}` : ""}</p>
                    <p className="text-muted-foreground">{issue.message}</p>
                  </div>
                ))}
                {!application.validationIssues.length ? <p className="text-muted-foreground">No unresolved validation items.</p> : null}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Status History</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {application.statusHistory.length ? application.statusHistory.map((entry) => (
                <div key={entry.id} className="rounded-md border p-3">
                  <p className="font-medium capitalize">{entry.toStatus.replace(/_/g, " ")}</p>
                  <p className="text-muted-foreground">{entry.reason}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{entry.createdAt.toLocaleDateString()}</p>
                </div>
              )) : <p className="text-muted-foreground">No status history has been recorded yet.</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Interview Scheduling</CardTitle></CardHeader>
            <CardContent className="grid gap-4 text-sm">
              {canEditHrWorkflow ? <InterviewScheduler
                applicationId={application.id}
                interviewId={activeInterview?.id}
                scheduledAt={activeInterview?.scheduledAt?.toISOString() ?? null}
                location={activeInterview?.location}
                notes={activeInterview?.notes}
              /> : null}
              {application.interviewRecords.length ? application.interviewRecords.map((interview) => (
                <div key={interview.id} className="rounded-md border p-3">
                  <p className="font-medium capitalize">{interview.status}</p>
                  <p className="text-muted-foreground">
                    {interview.scheduledAt ? interview.scheduledAt.toLocaleString() : "Time not scheduled"} {interview.location ? `- ${interview.location}` : ""}
                  </p>
                  <p className="text-muted-foreground">{interview.notes ?? "Interview record created for future scheduling."}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Created {interview.createdAt.toLocaleDateString()}</p>
                </div>
              )) : <p className="text-muted-foreground">No interview record yet. Schedule an interview when the applicant is ready.</p>}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Onboarding Checklist</CardTitle></CardHeader>
            <CardContent className="grid gap-3 text-sm">
              {application.onboardingChecklist ? (
                <>
                  <p className="text-muted-foreground">
                    Progress: {completedOnboardingItems} of {onboardingItems.length} items complete or waived.
                  </p>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Update</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {onboardingItems.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <p className="font-medium">{item.title}</p>
                            {item.description && <p className="text-xs text-muted-foreground">{item.description}</p>}
                          </TableCell>
                          <TableCell className="capitalize">{item.status.replace(/_/g, " ")}</TableCell>
                          <TableCell>{canEditHrWorkflow ? <OnboardingItemActions itemId={item.id} currentStatus={item.status} /> : "Read only"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </>
              ) : (
                <p className="text-muted-foreground">Onboarding is created automatically after HR approves the application for onboarding.</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>License Alerts</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {application.licenseAlerts.length ? application.licenseAlerts.map((alert) => (
                <div key={alert.id} className="rounded-md border border-orange-200 bg-orange-50 p-3 text-orange-900">
                  <p className="font-medium capitalize">{alert.alertType.replace(/_/g, " ")}</p>
                  <p>{alert.message}</p>
                </div>
              )) : <p className="text-muted-foreground">No open license alerts for this application.</p>}
            </CardContent>
          </Card>
        </div>

        {report && (
          <>
            <div className="grid gap-4 lg:grid-cols-3">
              <Card>
                <CardHeader><CardTitle>Strengths</CardTitle></CardHeader>
                <CardContent className="grid gap-2 text-sm">{strengths.length ? strengths.map((item) => <p key={item}>• {item}</p>) : <p className="text-muted-foreground">No strengths recorded.</p>}</CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle>Concerns</CardTitle></CardHeader>
                <CardContent className="grid gap-2 text-sm">{concerns.length ? concerns.map((item) => <p key={item}>• {item}</p>) : <p className="text-muted-foreground">No concerns recorded.</p>}</CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle>HR Action Items</CardTitle></CardHeader>
                <CardContent className="grid gap-2 text-sm">{actionItems.map((item) => <p key={item}>• {item}</p>)}</CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader><CardTitle>Findings</CardTitle></CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Severity</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Description</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {report.findings.map((finding) => (
                      <TableRow key={finding.id}>
                        <TableCell className="capitalize">{finding.severity}</TableCell>
                        <TableCell className="capitalize">{finding.category.replace(/_/g, " ")}</TableCell>
                        <TableCell>{finding.title}</TableCell>
                        <TableCell>{finding.description}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <div className="grid gap-4 lg:grid-cols-2">
              <ReviewJsonCard title="Pediatric Experience Review" data={report.pediatricExperienceJson} />
              <ReviewJsonCard title="License Review" data={report.licenseReviewJson} />
              <ReviewJsonCard title="Employment Review" data={report.employmentReviewJson} />
              <ReviewJsonCard title="Document Review" data={report.documentReviewJson} />
              <ReviewJsonCard title="Discrepancy Findings" data={report.discrepancyJson} />
            </div>
          </>
        )}
      </div>
    </DashboardShell>
  );
}
