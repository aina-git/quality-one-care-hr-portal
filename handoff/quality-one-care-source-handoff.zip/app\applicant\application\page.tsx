import { ArrowRight, Save } from "lucide-react";
import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { DocumentUploadForm } from "@/components/DocumentUploadForm";
import { ResubmitApplicationButton } from "@/components/ResubmitApplicationButton";
import { SubmitApplicationButton } from "@/components/SubmitApplicationButton";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ValidationChecklist } from "@/components/ValidationChecklist";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { applicationPageSections, getOrCreateApplicantApplication } from "@/services/applicationService";
import { validateApplication } from "@/services/validation/applicationValidationService";

export default async function ApplicantApplicationPage() {
  const user = await requireRole(["applicant"]);
  const { application } = await getOrCreateApplicantApplication(user.id);
  const [documents, validation] = await Promise.all([
    prisma.uploadedDocument.findMany({ where: { applicationId: application.id }, orderBy: { createdAt: "desc" } }),
    validateApplication(application.id, user.id)
  ]);

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/applicant/dashboard", label: "Dashboard" },
        { href: "/applicant/application", label: "Application" },
        { href: "/applicant/intake-review", label: "Intake Review" },
        { href: "/applicant/messages", label: "Messages" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Application Workspace</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Complete your application</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            Phase 1 provides the foundation and section structure. Detailed form logic arrives in the next phase.
          </p>
        </section>

        <section className="grid gap-4">
          <div>
            <h2 className="text-xl font-semibold tracking-normal">Upload Documents</h2>
            <p className="mt-1 text-sm text-muted-foreground">Upload required documents for OCR and intake review.</p>
          </div>
          <DocumentUploadForm />
          {documents.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Uploaded Documents</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {documents.map((doc) => (
                  <div key={doc.id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border p-3">
                    <span>{doc.fileName}</span>
                    <span className="text-muted-foreground">{doc.detectedDocumentType ?? "detecting"} · {doc.processingStatus}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </section>

        <div className="grid gap-4">
          {applicationPageSections.map((section, index) => (
            <Card key={section}>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-100 text-sm text-orange-700">{index + 1}</span>
                  {section}
                </CardTitle>
                <CardDescription>UI section placeholder for Phase 1.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border border-dashed bg-slate-50 p-4 text-sm text-muted-foreground">
                  Fields and validation will be expanded without changing the application shell.
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex flex-wrap gap-3">
          <Button variant="outline"><Save size={16} /> Save Draft</Button>
          <Button asChild><Link href="/applicant/intake-review">Continue <ArrowRight size={16} /></Link></Button>
        </div>
        <ValidationChecklist {...validation} documents={documents.map((document) => ({ id: document.id, fileName: document.fileName, documentType: document.documentType }))} />
        {application.status === "correction_requested" ? (
          <ResubmitApplicationButton canShow={validation.canSubmit} />
        ) : (
          <SubmitApplicationButton canSubmit={validation.canSubmit} />
        )}
      </div>
    </DashboardShell>
  );
}
