import Link from "next/link";
import { redirect } from "next/navigation";
import { CreateVerificationButton } from "@/components/CreateVerificationButton";
import { MessageComposer } from "@/components/MessageComposer";
import { RecommendationBadge, RiskBadge } from "@/components/ReviewBadges";
import { StatusBadge } from "@/components/StatusBadge";
import { SubmitToDonButton } from "@/components/SubmitToDonButton";
import { UnsortedDocumentActions } from "@/components/UnsortedDocumentActions";
import { ProfilePhoto } from "@/components/ProfilePhoto";
import { VerificationItemForm } from "@/components/VerificationItemForm";
import { DocumentPreviewLink } from "@/components/DocumentPreviewLink";
import { HrFieldOverrideForm } from "@/components/HrFieldOverrideForm";
import { DashboardShell } from "@/components/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getVerificationChecklist, summarizeChecklist } from "@/services/verification/verificationService";
import { getVerificationLink } from "@/services/verification/verificationLinks";
import { splitMatchedAndUnmatchedDocuments } from "@/services/verification/documentMatchingService";
import { healthcarePrecisionWarning } from "@/services/analysis/precisionReviewService";

const verificationInstructions: Record<string, string[]> = {
  maryland_board_of_nursing: [
    "Confirm RN/LPN license is current and active.",
    "Search by applicant name or license number.",
    "Record license type, license number, status, and expiration date.",
    "Upload screenshot or PDF evidence."
  ],
  nursys: [
    "Confirm nursing license status where applicable.",
    "Search by applicant name or license number.",
    "Upload verification evidence."
  ],
  oig_exclusion: [
    "Confirm applicant is not excluded from federal healthcare programs.",
    "Search applicant name.",
    "Record result and upload evidence."
  ],
  maryland_case_search: [
    "Search applicant name.",
    "Record result and upload evidence.",
    "Flag any result requiring HR/DON review."
  ],
  background_check_cgis: [
    "Agency Name: Quality One Care Home Health Inc.",
    "MA Provider Number: 420641000.",
    "Record applicant name, tracking number, date sent, person completing verification, receipt upload, and result."
  ],
  liability_insurance_nso: [
    "Confirm liability insurance where required.",
    "Record policyholder, policy number, expiration, and result.",
    "Upload evidence."
  ],
  cpr: [
    "Confirm current and active CPR.",
    "Record provider, issue date, expiration date, and result.",
    "Upload evidence."
  ]
};

const verificationPlan: Record<string, { website: string; searchFields: string; expectedResult: string; fallback: string }> = {
  maryland_board_of_nursing: {
    website: "Maryland Board of Nursing license lookup",
    searchFields: "Applicant name or license number",
    expectedResult: "Current active RN/LPN license, license number, type, status, and expiration date",
    fallback: "If the lookup is unavailable, record manual follow-up and upload the applicant-provided license copy."
  },
  nursys: {
    website: "Nursys verification",
    searchFields: "Applicant name and nursing license number",
    expectedResult: "License status and jurisdiction verification where applicable",
    fallback: "Record manual verification attempt and request applicant clarification if status cannot be confirmed."
  },
  oig_exclusion: {
    website: "OIG exclusions search",
    searchFields: "Applicant legal name",
    expectedResult: "No exclusion match, or documented match requiring HR/DON review",
    fallback: "Document the unavailable search and return the item for follow-up."
  },
  maryland_case_search: {
    website: "Maryland Case Search",
    searchFields: "Applicant legal name",
    expectedResult: "Recorded case-search result and whether DON review is needed",
    fallback: "Document manual search limitation and add HR note."
  },
  background_check_cgis: {
    website: "CGIS/background check receipt workflow",
    searchFields: "Agency Name, MA Provider Number, applicant name, tracking number, date sent, person completing verification",
    expectedResult: "Receipt uploaded, tracking number recorded, and result recorded",
    fallback: "Request receipt from HR processor or applicant file and mark needs follow-up."
  },
  liability_insurance_nso: {
    website: "NSO liability insurance verification where applicable",
    searchFields: "Policyholder name and policy number",
    expectedResult: "Current policy, policy number, expiration date, and coverage result",
    fallback: "Upload applicant-provided policy page and record manual review."
  },
  cpr: {
    website: "CPR provider verification where available",
    searchFields: "Applicant name, provider, issue date, certificate number if present",
    expectedResult: "Current active CPR/BLS certification with expiration date",
    fallback: "Upload CPR card and record manual review."
  }
};

function label(value: string | null | undefined) {
  if (!value) return "-";
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function fieldValue(fields: Array<{ fieldKey: string; extractedValue: string; sourceDocumentId: string }>, keys: string[], documentId?: string | null) {
  const field = fields.find((item) => keys.includes(item.fieldKey) && (!documentId || item.sourceDocumentId === documentId));
  return field?.extractedValue ?? "";
}

function mismatchWarnings({
  applicationName,
  applicationLicenseNumber,
  applicationLicenseType,
  applicationExpiration,
  extractedName,
  extractedLicenseNumber,
  extractedLicenseType,
  extractedExpiration
}: {
  applicationName: string;
  applicationLicenseNumber?: string | null;
  applicationLicenseType?: string | null;
  applicationExpiration?: Date | null;
  extractedName?: string;
  extractedLicenseNumber?: string;
  extractedLicenseType?: string;
  extractedExpiration?: string;
}) {
  const warnings: string[] = [];
  if (extractedName && !applicationName.toLowerCase().includes(extractedName.toLowerCase()) && !extractedName.toLowerCase().includes(applicationName.toLowerCase())) {
    warnings.push("Name in uploaded credential may not match the applicant profile.");
  }
  if (applicationLicenseNumber && extractedLicenseNumber && applicationLicenseNumber.replace(/\W/g, "").toLowerCase() !== extractedLicenseNumber.replace(/\W/g, "").toLowerCase()) {
    warnings.push("License number differs between application data and extracted credential data.");
  }
  if (applicationLicenseType && extractedLicenseType && !applicationLicenseType.toLowerCase().includes(extractedLicenseType.toLowerCase()) && !extractedLicenseType.toLowerCase().includes(applicationLicenseType.toLowerCase())) {
    warnings.push("Credential type appears different from the entered license/certification type.");
  }
  if (applicationExpiration && extractedExpiration && !applicationExpiration.toISOString().slice(0, 10).includes(extractedExpiration.slice(0, 10))) {
    warnings.push("Expiration date may differ between application data and uploaded credential data.");
  }
  return warnings;
}

function VerificationStatusBadge({ status }: { status: string }) {
  const classes = status === "verified"
    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
    : status === "failed" || status === "expired"
      ? "border-red-200 bg-red-50 text-red-700"
      : status === "not_applicable"
        ? "border-slate-200 bg-slate-50 text-slate-600"
        : status === "pending_external_check"
          ? "border-blue-200 bg-blue-50 text-blue-700"
          : "border-orange-200 bg-orange-50 text-orange-700";
  return <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${classes}`}>{label(status)}</span>;
}

export default async function HrFinalVerificationPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireRole(["hr", "admin", "super_admin_hr", "don_approver", "executive_view_only"]);
  const { id } = await params;
  const application = await prisma.application.findUnique({
    where: { id },
    include: {
      applicantProfile: { include: { user: true } },
      documents: true,
      aiReviewReports: { orderBy: { createdAt: "desc" }, take: 1 },
      decisions: { orderBy: { createdAt: "desc" }, take: 1 }
    }
  });
  if (!application) redirect("/hr/applications");

  const checklist = await getVerificationChecklist(application.id);
  const report = application.aiReviewReports[0];
  const latestDecision = application.decisions[0];
  const profilePhoto = await prisma.uploadedDocument.findFirst({
    where: { applicantProfileId: application.applicantProfileId, documentType: "profile_photo" },
    orderBy: { createdAt: "desc" }
  });
  const summary = checklist ? summarizeChecklist(checklist) : null;
  const extractedFields = await prisma.extractedField.findMany({
    where: { applicationId: application.id },
    orderBy: { createdAt: "desc" }
  });
  const fieldAssertions = await prisma.applicantFieldAssertion.findMany({
    where: { applicationId: application.id },
    include: { sourceDocument: true },
    orderBy: { createdAt: "desc" }
  });
  const documents = application.documents.map((document) => ({
    id: document.id,
    fileName: document.fileName,
    documentType: document.documentType,
    detectedDocumentType: document.detectedDocumentType
  }));
  const canEdit = ["hr", "admin", "super_admin_hr"].includes(user.role);
  const matchedUploads = checklist ? splitMatchedAndUnmatchedDocuments(documents, checklist.items) : { matched: [], unmatched: documents };
  const auditLogs = checklist ? await prisma.auditLog.findMany({
    where: {
      OR: [
        { entityId: application.id },
        { entityId: checklist.id },
        { entityId: { in: checklist.items.map((item) => item.id) } }
      ]
    },
    include: { user: true },
    orderBy: { createdAt: "desc" },
    take: 30
  }) : [];

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/hr/dashboard", label: "Dashboard" },
        { href: "/hr/applications", label: "Applications" },
        { href: "/hr/verification", label: "Final Verification" },
        { href: "/don/approval-queue", label: "DON Queue" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <div className="flex flex-wrap items-center gap-4">
            <ProfilePhoto document={profilePhoto} viewerUserId={user.id} name={application.applicantProfile.user.name ?? application.applicantProfile.user.email} />
            <div>
              <p className="text-sm font-medium text-orange-600">Final Employment Verification</p>
              <h1 className="mt-2 text-3xl font-semibold tracking-normal">{application.applicantProfile.user.name ?? application.applicantProfile.user.email}</h1>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <StatusBadge status={application.status} />
            {report ? <RiskBadge risk={report.overallRiskLevel} /> : null}
            {report ? <RecommendationBadge recommendation={report.recommendation} /> : null}
            {latestDecision ? <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700">{label(latestDecision.action)}</span> : null}
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button asChild variant="outline"><Link href={`/hr/applications/${application.id}/review`}>Back to HR Review</Link></Button>
            <Button asChild variant="outline"><Link href="/hr/verification">Verification Queue</Link></Button>
            {checklist ? <Button asChild variant="outline"><Link href={`/don/final-approval/${application.id}`}>DON Approval Report</Link></Button> : null}
          </div>
        </section>
        <section className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-900">
          {healthcarePrecisionWarning()}
        </section>

        {!checklist ? (
          <Card>
            <CardHeader><CardTitle>Checklist Not Created</CardTitle></CardHeader>
            <CardContent className="grid gap-3 text-sm">
              <p className="text-muted-foreground">Final verification starts after HR approves the application for onboarding.</p>
              {application.status === "approved" && canEdit ? <CreateVerificationButton applicationId={application.id} /> : <p>Current status: {label(application.status)}</p>}
              {fieldAssertions.length ? (
                <div className="mt-2 grid gap-2 rounded-md border border-blue-200 bg-blue-50 p-3 text-blue-950">
                  <p className="font-semibold">Applicant notes waiting for HR review</p>
                  {fieldAssertions.map((assertion) => (
                    <div key={assertion.id} className="rounded-md bg-white/70 p-2">
                      <p className="font-medium">{label(assertion.fieldKey)} - {label(assertion.status)}</p>
                      <p>{assertion.note}</p>
                      <p className="text-xs">Source: {assertion.sourceDocument?.fileName ?? "No source document attached"} - {assertion.createdAt.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              ) : null}
              {application.documents.length ? (
                <div className="mt-2 grid gap-2 rounded-md border bg-slate-50 p-3">
                  <p className="font-semibold">Uploaded pages and supporting documents</p>
                  {application.documents.map((document) => (
                    <p key={document.id} className="text-xs">{document.fileName} - {document.documentType}</p>
                  ))}
                </div>
              ) : null}
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Completion</CardTitle></CardHeader>
                <CardContent><div className="text-3xl font-semibold">{summary?.completionPercentage ?? 0}%</div></CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Missing Items</CardTitle></CardHeader>
                <CardContent><div className="text-3xl font-semibold">{summary?.missingItems.length ?? 0}</div></CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Expired Items</CardTitle></CardHeader>
                <CardContent><div className="text-3xl font-semibold">{summary?.expiredItems.length ?? 0}</div></CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">DON Ready</CardTitle></CardHeader>
                <CardContent><div className="text-3xl font-semibold">{summary?.readyForDon ? "Yes" : "No"}</div></CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader><CardTitle>Readiness Summary</CardTitle></CardHeader>
              <CardContent className="grid gap-3 text-sm">
                <p>Status: <span className="font-medium">{label(checklist.status)}</span></p>
                {summary?.criticalBlockers.length ? (
                  <div className="rounded-md border border-red-200 bg-red-50 p-3 text-red-800">
                    <p className="font-medium">Critical blockers</p>
                    <ul className="mt-2 list-disc pl-5">
                      {summary.criticalBlockers.map((item) => <li key={item.id}>{item.title}: {label(item.status)}</li>)}
                    </ul>
                  </div>
                ) : <p className="rounded-md border border-emerald-200 bg-emerald-50 p-3 text-emerald-800">No critical blockers are currently recorded.</p>}
                {summary?.warnings.length ? (
                  <div className="rounded-md border border-orange-200 bg-orange-50 p-3 text-orange-800">
                    <p className="font-medium">Warnings needing HR explanation</p>
                    <ul className="mt-2 list-disc pl-5">
                      {summary.warnings.map((item) => <li key={item.id}>{item.title}: {item.notes || "HR note needed"}</li>)}
                    </ul>
                  </div>
                ) : null}
                {checklist && canEdit ? <SubmitToDonButton applicationId={application.id} /> : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Field-Level Confidence and Applicant Correction History</CardTitle></CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Field</TableHead>
                      <TableHead>Confidence</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Applicant Review</TableHead>
                      <TableHead>HR Override</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {extractedFields.map((field) => (
                      <TableRow key={field.id}>
                        <TableCell>
                          <p className="font-medium">{field.fieldLabel}</p>
                          <p className="text-xs text-muted-foreground">{field.mappedSection} - {field.fieldKey}</p>
                          {field.reviewReason ? <p className="mt-1 text-xs font-semibold text-red-700">{field.reviewReason}</p> : null}
                        </TableCell>
                        <TableCell>
                          <span className={field.confidence >= 0.9 ? "font-semibold text-green-700" : "font-semibold text-red-700"}>{Math.round(field.confidence * 100)}%</span>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm">{field.sourceDocumentName ?? "Source document"}</p>
                          <DocumentPreviewLink documentId={field.sourceDocumentId} />
                          {field.sourceSnippet ? <p className="mt-1 max-w-md text-xs text-muted-foreground">{field.sourceSnippet}</p> : null}
                        </TableCell>
                        <TableCell>
                          <p className="capitalize">{field.status.replace(/_/g, " ")}</p>
                          <p className="text-xs text-muted-foreground">Extracted: {field.extractedValue || "-"}</p>
                          {field.applicantCorrectedValue ? <p className="text-xs text-blue-700">Corrected: {field.applicantCorrectedValue}</p> : null}
                          {field.correctedAt ? <p className="text-xs text-muted-foreground">{field.correctedAt.toLocaleString()}</p> : null}
                        </TableCell>
                        <TableCell>
                          {field.hrOverrideNote ? (
                            <div className="rounded-md border border-purple-200 bg-purple-50 p-2 text-xs text-purple-900">
                              <p className="font-semibold">Override applied</p>
                              <p>{field.hrOverrideNote}</p>
                            </div>
                          ) : canEdit ? <HrFieldOverrideForm fieldId={field.id} /> : <p className="text-sm text-muted-foreground">Read only</p>}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {!extractedFields.length ? <p className="text-sm text-muted-foreground">No extracted fields are available yet.</p> : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Applicant Notes Sent to HR Review</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {fieldAssertions.map((assertion) => (
                  <div key={assertion.id} className="rounded-md border border-blue-200 bg-blue-50 p-3 text-blue-950">
                    <p className="font-semibold">{label(assertion.fieldKey)} - {label(assertion.status)}</p>
                    <p className="mt-1">{assertion.note}</p>
                    <p className="mt-1 text-xs">Source: {assertion.sourceDocument?.fileName ?? "No source document attached"} - {assertion.createdAt.toLocaleString()}</p>
                  </div>
                ))}
                {!fieldAssertions.length ? <p className="text-muted-foreground">No applicant notes have been sent to HR review.</p> : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Verification Checklist</CardTitle></CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Checklist Item</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Evidence</TableHead>
                      <TableHead>Verified</TableHead>
                      <TableHead>Update</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {checklist.items.map((item) => {
                      const link = getVerificationLink(item.category);
                      const plan = verificationPlan[item.category];
                      const suggestions = matchedUploads.matched.filter((entry) => entry.category === item.category).map((entry) => entry.document);
                      const license = checklist.application.licenses[0];
                      const documentId = item.documentId ?? suggestions[0]?.id;
                      const extractedName = [fieldValue(extractedFields, ["firstName", "name"], documentId), fieldValue(extractedFields, ["lastName"], documentId)].filter(Boolean).join(" ");
                      const extractedLicenseNumber = fieldValue(extractedFields, ["licenseNumber"], documentId);
                      const extractedLicenseType = fieldValue(extractedFields, ["licenseType", "certificationType"], documentId);
                      const extractedIssueDate = fieldValue(extractedFields, ["issueDate"], documentId);
                      const extractedExpiration = fieldValue(extractedFields, ["expirationDate"], documentId);
                      const warnings = mismatchWarnings({
                        applicationName: application.applicantProfile.user.name ?? application.applicantProfile.user.email,
                        applicationLicenseNumber: license?.licenseNumber,
                        applicationLicenseType: license?.type,
                        applicationExpiration: license?.expiresAt,
                        extractedName,
                        extractedLicenseNumber,
                        extractedLicenseType,
                        extractedExpiration
                      });
                      return (
                        <TableRow key={item.id}>
                          <TableCell className="align-top">
                            <p className="font-medium">{item.title}</p>
                            <p className="mt-1 text-xs text-muted-foreground">{item.requirement}</p>
                            {item.category === "background_check_cgis" ? (
                              <p className="mt-2 text-xs text-slate-700">Agency: Quality One Care Home Health Inc. MA Provider Number: 420641000</p>
                            ) : null}
                            {link ? <p className="mt-2 text-xs"><a className="text-orange-700 underline" href={link.searchUrl} target="_blank" rel="noreferrer">{link.providerName}</a></p> : null}
                            {suggestions.length ? (
                              <div className="mt-2 rounded-md border border-emerald-200 bg-emerald-50 p-2 text-xs text-emerald-900">
                                <p className="font-semibold">Suggested matched upload</p>
                                {suggestions.map((document) => <p key={document.id}>{document.fileName} ({document.documentType})</p>)}
                              </div>
                            ) : null}
                            {item.result ? <p className="mt-2 text-sm">{item.result}</p> : null}
                            {item.notes ? <p className="mt-1 text-xs text-muted-foreground">{item.notes}</p> : null}
                            <div className="mt-3 rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900">
                              <p className="font-semibold">How to verify this item</p>
                              {plan ? (
                                <div className="mt-2 grid gap-1">
                                  <p><span className="font-semibold">Official method:</span> {plan.website}</p>
                                  <p><span className="font-semibold">Search fields:</span> {plan.searchFields}</p>
                                  <p><span className="font-semibold">Capture:</span> {plan.expectedResult}</p>
                                  <p><span className="font-semibold">Manual fallback:</span> {plan.fallback}</p>
                                  <p className="font-semibold text-red-700">Security: do not store external website passwords or scrape protected sites.</p>
                                </div>
                              ) : null}
                              <ul className="mt-2 list-disc pl-4">
                                {(verificationInstructions[item.category] ?? ["Review the required standard.", "Record result, status, notes, expiration when applicable, and upload evidence."]).map((step) => <li key={step}>{step}</li>)}
                              </ul>
                            </div>
                            <div className="mt-3 grid gap-2 rounded-md border border-slate-200 bg-white p-3 text-xs lg:grid-cols-2">
                              <div>
                                <p className="font-semibold text-slate-900">Application data</p>
                                <p>Name: {application.applicantProfile.user.name ?? application.applicantProfile.user.email}</p>
                                <p>Credential/license number: {license?.licenseNumber ?? "-"}</p>
                                <p>Credential type: {license?.type ?? "-"}</p>
                                <p>Issue date: {license?.issueDate?.toLocaleDateString() ?? "-"}</p>
                                <p>Expiration: {license?.expiresAt?.toLocaleDateString() ?? "-"}</p>
                                <p>Issuing authority: {license?.issuingState ?? item.source ?? "-"}</p>
                              </div>
                              <div>
                                <p className="font-semibold text-slate-900">Uploaded credential data</p>
                                <p>Document uploaded: {item.document?.fileName ?? suggestions[0]?.fileName ?? "No matched evidence yet"}</p>
                                <p>Extracted name: {extractedName || "-"}</p>
                                <p>Credential/license number: {extractedLicenseNumber || "-"}</p>
                                <p>Credential type: {extractedLicenseType || "-"}</p>
                                <p>Issue date: {extractedIssueDate || "-"}</p>
                                <p>Expiration: {extractedExpiration || "-"}</p>
                                <p>Issuing authority: {fieldValue(extractedFields, ["issuingState", "issuer"], documentId) || item.source || "-"}</p>
                              </div>
                              <div className="lg:col-span-2">
                                <p className="font-semibold text-slate-900">Mismatch warnings</p>
                                {warnings.length ? (
                                  <ul className="mt-1 list-disc pl-4 text-red-700">
                                    {warnings.map((warning) => <li key={warning}>{warning}</li>)}
                                  </ul>
                                ) : <p className="text-emerald-700">No obvious mismatch found from available extracted data.</p>}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="align-top"><VerificationStatusBadge status={item.status} /></TableCell>
                          <TableCell className="align-top text-sm">
                            {item.document ? (
                              <DocumentPreviewLink documentId={item.document.id} label={item.document.fileName} />
                            ) : "-"}
                            {item.externalReferenceNumber ? <p className="mt-1 text-xs text-muted-foreground">Ref: {item.externalReferenceNumber}</p> : null}
                            {item.expirationDate ? <p className="mt-1 text-xs text-muted-foreground">Expires: {item.expirationDate.toLocaleDateString()}</p> : null}
                          </TableCell>
                          <TableCell className="align-top text-sm">
                            {item.verifiedByUser ? <p>{item.verifiedByUser.name ?? item.verifiedByUser.email}</p> : <p>-</p>}
                            {item.verifiedAt ? <p className="text-xs text-muted-foreground">{item.verifiedAt.toLocaleString()}</p> : null}
                          </TableCell>
                          <TableCell className="align-top min-w-64">
                            {canEdit ? <VerificationItemForm itemId={item.id} category={item.category} currentStatus={item.status} documents={documents} /> : <p className="text-sm text-muted-foreground">Read only</p>}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Unmatched Uploads for HR Review</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {matchedUploads.unmatched.map((document) => (
                  <div key={document.id} className="grid gap-3 rounded-md border bg-slate-50 p-3 lg:grid-cols-[minmax(0,1fr)_320px]">
                    <div>
                      <p className="font-medium">{document.fileName}</p>
                      <p className="text-muted-foreground">{document.documentType}. Use the evidence document selector in the checklist to attach this upload to the correct item.</p>
                      <div className="mt-2">
                        <DocumentPreviewLink documentId={document.id} label="Preview Document" />
                      </div>
                    </div>
                    <UnsortedDocumentActions documentId={document.id} compact />
                  </div>
                ))}
                {!matchedUploads.unmatched.length ? <p className="text-muted-foreground">No unmatched uploads. Uploaded credentials are either attached or have a suggested checklist match.</p> : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Messaging</CardTitle></CardHeader>
              <CardContent>
                {canEdit ? <MessageComposer applicationId={application.id} /> : <p className="text-sm text-muted-foreground">Read-only roles cannot send messages from verification.</p>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Audit Trail</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {auditLogs.map((entry) => {
                  const details = entry.details && typeof entry.details === "object" && !Array.isArray(entry.details) ? entry.details as Record<string, unknown> : {};
                  return (
                    <div key={entry.id} className="rounded-md border bg-slate-50 p-3">
                      <p className="font-medium">{entry.action}</p>
                      <p className="text-xs text-muted-foreground">{entry.createdAt.toLocaleString()} by {entry.user?.name ?? entry.user?.email ?? "System"} on {entry.entityType} {entry.entityId ?? ""}</p>
                      <div className="mt-2 grid gap-1 text-xs">
                        <p>Old value: {JSON.stringify(details.oldValue ?? "-")}</p>
                        <p>New value: {JSON.stringify(details.newValue ?? "-")}</p>
                        <p>Notes: {JSON.stringify(details.notes ?? details.status ?? details.decision ?? "-")}</p>
                      </div>
                    </div>
                  );
                })}
                {!auditLogs.length ? <p className="text-muted-foreground">No verification audit entries yet.</p> : null}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </DashboardShell>
  );
}
