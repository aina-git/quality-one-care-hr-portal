import { DashboardShell } from "@/components/DashboardShell";
import { OperationalPulse } from "@/components/OperationalPulse";
import { TaskForm } from "@/components/TaskForm";
import { TaskStatusActions } from "@/components/TaskStatusActions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

function priorityColor(priority: string) {
  if (priority === "urgent") return "bg-red-100 text-red-800";
  if (priority === "high") return "bg-orange-100 text-orange-800";
  if (priority === "normal") return "bg-blue-100 text-blue-800";
  return "bg-slate-100 text-slate-700";
}

export default async function TasksPage() {
  const user = await requireAuth();
  const where: Prisma.TaskWhereInput = {};
  if (user.role === "applicant") where.OR = [{ assignedToUserId: user.id }, { relatedApplicantUserId: user.id }];
  if (user.role === "scheduler_limited") where.relatedApplication = { status: "approved" };
  const tasks = await prisma.task.findMany({
    where,
    include: { relatedApplication: { include: { applicantProfile: { include: { user: true } } } }, assignedToUser: true },
    orderBy: [{ dueDate: "asc" }, { createdAt: "desc" }],
    take: 100
  });
  const now = new Date();
  const overdue = tasks.filter((task) => task.status !== "completed" && task.dueDate && task.dueDate < now).length;
  const today = tasks.filter((task) => task.dueDate && task.dueDate.toDateString() === now.toDateString()).length;
  const canCreate = user.role !== "executive_view_only" && user.role !== "don_approver";

  return (
    <DashboardShell user={user} nav={[]}>
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Tasks</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Work queue and to-do list</h1>
        </section>
        <div className="grid gap-4 sm:grid-cols-4">
          <OperationalPulse label="Open Tasks" value={tasks.filter((task) => task.status !== "completed").length} icon="clock" color="blue" />
          <OperationalPulse label="Due Today" value={today} icon="bell" color="orange" />
          <OperationalPulse label="Overdue" value={overdue} icon="alert" color="red" />
          <OperationalPulse label="Completed" value={tasks.filter((task) => task.status === "completed").length} icon="check" color="green" />
        </div>
        {canCreate ? <Card><CardHeader><CardTitle>Create Task</CardTitle></CardHeader><CardContent><TaskForm /></CardContent></Card> : null}
        <Card>
          <CardHeader><CardTitle>Task List</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader><TableRow><TableHead>Task</TableHead><TableHead>Priority</TableHead><TableHead>Due</TableHead><TableHead>Applicant</TableHead><TableHead>Status</TableHead><TableHead>Action</TableHead></TableRow></TableHeader>
              <TableBody>
                {tasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell><p className="font-medium">{task.title}</p><p className="text-xs text-muted-foreground">{task.description}</p></TableCell>
                    <TableCell><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${priorityColor(task.priority)}`}>{task.priority}</span></TableCell>
                    <TableCell>{task.dueDate ? task.dueDate.toLocaleString() : "-"}</TableCell>
                    <TableCell>{task.relatedApplication?.applicantProfile.user.name ?? task.relatedApplication?.applicantProfile.user.email ?? "-"}</TableCell>
                    <TableCell className="capitalize">{task.status.replace(/_/g, " ")}</TableCell>
                    <TableCell>{canCreate ? <TaskStatusActions taskId={task.id} /> : "Read only"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
