import Link from "next/link";
import { redirect } from "next/navigation";
import { DonDecisionForm } from "@/components/DonDecisionForm";
import { DashboardShell } from "@/components/DashboardShell";
import { MessageComposer } from "@/components/MessageComposer";
import { ProfilePhoto } from "@/components/ProfilePhoto";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { logAction } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getVerificationChecklist, summarizeChecklist } from "@/services/verification/verificationService";

function label(value: string | null | undefined) {
  if (!value) return "-";
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

export default async function DonFinalApprovalPage({ params }: { params: Promise<{ applicationId: string }> }) {
  const user = await requireRole(["admin", "super_admin_hr", "don_approver", "executive_view_only"]);
  const { applicationId } = await params;
  const checklist = await getVerificationChecklist(applicationId);
  if (!checklist) redirect("/admin/dashboard");
  await logAction(user.id, "don_approval_viewed", "application", applicationId);

  const summary = summarizeChecklist(checklist);
  const application = checklist.application;
  const applicant = application.applicantProfile;
  const latestLicense = application.licenses[0];
  const profilePhoto = await prisma.uploadedDocument.findFirst({
    where: { applicantProfileId: applicant.id, documentType: "profile_photo" },
    orderBy: { createdAt: "desc" }
  });
  const canDecide = ["admin", "super_admin_hr", "don_approver"].includes(user.role);
  const auditLogs = await prisma.auditLog.findMany({
    where: {
      OR: [
        { entityId: application.id },
        { entityId: checklist.id },
        { entityId: { in: checklist.items.map((item) => item.id) } }
      ]
    },
    include: { user: true },
    orderBy: { createdAt: "desc" },
    take: 30
  });

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/admin/dashboard", label: "Dashboard" },
        { href: "/admin/analytics", label: "Analytics" },
        { href: "/admin/system-health", label: "System Health" },
        { href: "/admin/users", label: "Users" },
        { href: "/admin/audit", label: "Audit" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Quality One Care Home Health Inc.</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Final Employment Verification for Hire Approval</h1>
          <div className="mt-4 flex flex-wrap gap-2">
            <StatusBadge status={application.status} />
            <span className="inline-flex rounded-full border border-orange-200 bg-orange-50 px-2.5 py-1 text-xs font-medium text-orange-700">{label(checklist.status)}</span>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button asChild variant="outline"><Link href={`/hr/applications/${application.id}/verification`}>Open HR Verification</Link></Button>
            <Button asChild variant="outline"><Link href={`/don/final-approval/${application.id}/print`}>Printable Report</Link></Button>
          </div>
        </section>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Applicant</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              <ProfilePhoto document={profilePhoto} viewerUserId={user.id} name={applicant.user.name ?? applicant.user.email} size="lg" />
              <p>Name: <span className="font-medium">{applicant.user.name ?? applicant.user.email}</span></p>
              <p>Position: <span className="font-medium">{application.desiredRole ?? "Not recorded"}</span></p>
              <p>Phone: <span className="font-medium">{applicant.phone ?? "Not recorded"}</span></p>
              <p>Email: <span className="font-medium">{applicant.user.email}</span></p>
              <p>License Type: <span className="font-medium">{latestLicense?.type ?? "Not recorded"}</span></p>
              <p>License Number: <span className="font-medium">{latestLicense?.licenseNumber ?? "Not recorded"}</span></p>
              <p>Submitted: <span className="font-medium">{application.submittedAt ? application.submittedAt.toLocaleString() : "Not submitted"}</span></p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Verification Summary</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              <p>Overall status: <span className="font-medium">{label(checklist.status)}</span></p>
              <p>Completion: <span className="font-medium">{summary.completionPercentage}%</span></p>
              <p>Critical missing/blocking items: <span className="font-medium">{summary.criticalBlockers.length}</span></p>
              <p>Expired items: <span className="font-medium">{summary.expiredItems.length}</span></p>
              <p>Failed items: <span className="font-medium">{summary.failedItems.length}</span></p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Checklist</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Checklist Item</TableHead>
                  <TableHead>Required Standard</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Result</TableHead>
                  <TableHead>Expiration</TableHead>
                  <TableHead>Evidence</TableHead>
                  <TableHead>Verified By</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {checklist.items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.title}</TableCell>
                    <TableCell>{item.requirement}</TableCell>
                    <TableCell>{label(item.status)}</TableCell>
                    <TableCell>{item.result ?? "-"}</TableCell>
                    <TableCell>{item.expirationDate ? item.expirationDate.toLocaleDateString() : "-"}</TableCell>
                    <TableCell>{item.document ? item.document.fileName : "-"}</TableCell>
                    <TableCell>{item.verifiedByUser ? `${item.verifiedByUser.name ?? item.verifiedByUser.email}${item.verifiedAt ? ` on ${item.verifiedAt.toLocaleDateString()}` : ""}` : "-"}</TableCell>
                    <TableCell>{item.notes ?? "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>DON Decision</CardTitle></CardHeader>
          <CardContent className="grid gap-4">
            {!summary.readyForDon ? (
              <div className="rounded-md border border-orange-200 bg-orange-50 p-3 text-sm text-orange-800">
                Final approval is blocked until all required checklist items are verified or marked not applicable with notes.
              </div>
            ) : null}
            {checklist.donDecision ? (
              <div className="rounded-md border bg-slate-50 p-3 text-sm">
                <p className="font-medium">{label(checklist.donDecision)}</p>
                <p>{checklist.donComment ?? "No comments recorded."}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {checklist.approvedByUser ? checklist.approvedByUser.name ?? checklist.approvedByUser.email : "DON/Admin"} on {(checklist.approvedAt ?? checklist.rejectedAt ?? checklist.updatedAt).toLocaleString()}
                </p>
              </div>
            ) : null}
            {canDecide ? <DonDecisionForm applicationId={application.id} canApprove={summary.readyForDon} /> : <p className="text-sm text-muted-foreground">Executive access is read only.</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Communication</CardTitle></CardHeader>
          <CardContent>
            {canDecide ? <MessageComposer applicationId={application.id} /> : <p className="text-sm text-muted-foreground">Executive access is read-only.</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Audit Trail</CardTitle></CardHeader>
          <CardContent className="grid gap-2 text-sm">
            {auditLogs.map((entry) => {
              const details = entry.details && typeof entry.details === "object" && !Array.isArray(entry.details) ? entry.details as Record<string, unknown> : {};
              return (
                <div key={entry.id} className="rounded-md border bg-slate-50 p-3">
                  <p className="font-medium">{entry.action}</p>
                  <p className="text-xs text-muted-foreground">{entry.createdAt.toLocaleString()} by {entry.user?.name ?? entry.user?.email ?? "System"} on {entry.entityType} {entry.entityId ?? ""}</p>
                  <div className="mt-2 grid gap-1 text-xs">
                    <p>Old value: {JSON.stringify(details.oldValue ?? "-")}</p>
                    <p>New value: {JSON.stringify(details.newValue ?? "-")}</p>
                    <p>Notes: {JSON.stringify(details.notes ?? details.status ?? details.decision ?? "-")}</p>
                  </div>
                </div>
              );
            })}
            {!auditLogs.length ? <p className="text-muted-foreground">No DON or verification audit entries yet.</p> : null}
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
