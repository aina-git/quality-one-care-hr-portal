import { DashboardShell } from "@/components/DashboardShell";
import { DocumentPreviewLink } from "@/components/DocumentPreviewLink";
import { FieldReviewActions } from "@/components/FieldReviewActions";
import { ManualFieldForm } from "@/components/ManualFieldForm";
import { ResubmitApplicationButton } from "@/components/ResubmitApplicationButton";
import { StatusBadge } from "@/components/StatusBadge";
import { SubmitApplicationButton } from "@/components/SubmitApplicationButton";
import { ValidationChecklist } from "@/components/ValidationChecklist";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getLatestApplicantApplication } from "@/services/applicationService";
import { validateApplication } from "@/services/validation/applicationValidationService";
import { healthcarePrecisionWarning } from "@/services/analysis/precisionReviewService";

export default async function IntakeReviewPage() {
  const user = await requireRole(["applicant"]);
  const { application } = await getLatestApplicantApplication(user.id);
  if (!application) redirect("/applicant/application");
  const [documents, fields, validation] = await Promise.all([
    prisma.uploadedDocument.findMany({ where: { applicationId: application.id }, orderBy: { createdAt: "desc" } }),
    prisma.extractedField.findMany({ where: { applicationId: application.id }, orderBy: [{ mappedSection: "asc" }, { createdAt: "asc" }] }),
    validateApplication(application.id, user.id)
  ]);

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/applicant/dashboard", label: "Dashboard" },
        { href: "/applicant/application", label: "Application" },
        { href: "/applicant/intake-review", label: "Intake Review" },
        { href: "/applicant/messages", label: "Messages" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Applicant Intake Review</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Review extracted information</h1>
          <p className="mt-2 text-sm text-muted-foreground">Accept, correct, reject, or manually enter information before submission.</p>
          <div className="mt-4"><StatusBadge status={application.status} /></div>
        </section>
        <section className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-900">
          {healthcarePrecisionWarning()}
        </section>

        <Card id="manual-entry">
          <CardHeader><CardTitle>Uploaded Documents</CardTitle></CardHeader>
          <CardContent className="grid gap-2">
            {documents.length === 0 && <p className="text-sm text-muted-foreground">No documents uploaded yet.</p>}
            {documents.map((doc) => (
              <div key={doc.id} className="rounded-md border p-3 text-sm">
                <div className="font-medium">{doc.fileName}</div>
                <div className="mt-1 text-muted-foreground">Detected: {doc.detectedDocumentType ?? "pending"} · Confidence: {Math.round((doc.extractionConfidence ?? 0) * 100)}% · {doc.processingStatus}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Extracted Fields</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Section</TableHead>
                  <TableHead>Field</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Review</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fields.map((field) => (
                  <TableRow key={field.id}>
                    <TableCell>{field.mappedSection}</TableCell>
                    <TableCell>
                      <div className="font-medium">{field.fieldLabel}</div>
                      <div className="mt-1 text-xs text-slate-500">Document: {field.sourceDocumentName ?? "Source document"}</div>
                      <div className="mt-1"><DocumentPreviewLink documentId={field.sourceDocumentId} /></div>
                    </TableCell>
                    <TableCell>
                      <span className={field.confidence >= 0.9 ? "font-semibold text-green-700" : "font-semibold text-red-700"}>{Math.round(field.confidence * 100)}%</span>
                      {field.reviewReason ? <p className="mt-1 text-xs text-red-700">{field.reviewReason}</p> : <p className="mt-1 text-xs text-green-700">High confidence. Please confirm source.</p>}
                    </TableCell>
                    <TableCell className="capitalize">{field.status.replace(/_/g, " ")}</TableCell>
                    <TableCell className="min-w-[360px]">
                      <div className="mb-2 rounded-md border border-slate-200 bg-slate-50 p-2 text-xs text-slate-600">
                        <p className="font-semibold text-slate-800">Extracted value</p>
                        <p>{field.extractedValue || "No readable value"}</p>
                        {field.sourceSnippet ? <p className="mt-1 text-slate-500">Source context: {field.sourceSnippet}</p> : null}
                      </div>
                      {field.status === "pending_review" ? (
                        <FieldReviewActions fieldId={field.id} currentValue={field.extractedValue} />
                      ) : (
                        <span className="text-sm text-muted-foreground">{field.applicantCorrectedValue || field.extractedValue}</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {fields.length === 0 && <p className="mt-4 text-sm text-muted-foreground">No extracted fields are available yet. Upload documents or enter missing information manually.</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Manual Entry</CardTitle></CardHeader>
          <CardContent>
            <ManualFieldForm />
          </CardContent>
        </Card>

        <ValidationChecklist {...validation} documents={documents.map((document) => ({ id: document.id, fileName: document.fileName, documentType: document.documentType }))} />
        {application.status === "correction_requested" ? (
          <ResubmitApplicationButton canShow={validation.canSubmit} />
        ) : (
          <SubmitApplicationButton canSubmit={validation.canSubmit} />
        )}
      </div>
    </DashboardShell>
  );
}
import { redirect } from "next/navigation";
