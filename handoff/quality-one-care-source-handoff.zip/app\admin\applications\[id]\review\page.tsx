import Link from "next/link";
import { ApplicationWorkflowControls } from "@/components/ApplicationWorkflowControls";
import { DashboardShell } from "@/components/DashboardShell";
import { DocumentPreviewLink } from "@/components/DocumentPreviewLink";
import { HRDecisionPanel } from "@/components/HRDecisionPanel";
import { HrMissingInformationEditor } from "@/components/HrMissingInformationEditor";
import { MessageComposer } from "@/components/MessageComposer";
import { RecommendationBadge, RiskBadge } from "@/components/ReviewBadges";
import { RunReviewButton } from "@/components/RunReviewButton";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { adminNav } from "@/lib/adminNav";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function label(value: string | null | undefined) {
  if (!value) return "Not recorded";
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function dateLabel(date: Date | null | undefined) {
  return date ? date.toLocaleString() : "Not recorded";
}

export default async function AdminApplicationReviewPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireRole(["admin", "super_admin_hr", "executive_view_only"]);
  const { id } = await params;
  const application = await prisma.application.findUnique({
    where: { id },
    include: {
      applicantProfile: { include: { user: true } },
      documents: { orderBy: { createdAt: "desc" } },
      extractedFields: { orderBy: { createdAt: "desc" }, take: 12 },
      hrReviewQueue: true,
      aiReviewReports: { orderBy: { createdAt: "desc" }, take: 1, include: { findings: true } },
      validationIssues: { where: { resolved: false }, orderBy: { createdAt: "desc" } },
      tasks: { where: { category: "application_review" }, orderBy: { createdAt: "desc" }, take: 5 },
      systemAlerts: { where: { resolved: false }, orderBy: { createdAt: "desc" }, take: 8 },
      statusHistory: { include: { changedBy: true }, orderBy: { createdAt: "desc" }, take: 8 },
      applicantMessages: { orderBy: { createdAt: "desc" }, take: 8 },
      decisions: { orderBy: { createdAt: "desc" }, include: { createdBy: true }, take: 3 },
      employmentHistory: true,
      licenses: true,
      certifications: true,
      references: true
    }
  });

  return (
    <DashboardShell user={user} nav={adminNav}>
      {!application ? (
        <Card><CardContent className="p-6">Application not found.</CardContent></Card>
      ) : (
        <div className="grid gap-6">
          <section className="rounded-2xl border border-blue-200 bg-gradient-to-br from-white via-blue-50 to-orange-50 p-6 shadow-sm">
            <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
              <div>
                <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Super Admin Case Review</p>
                <h1 className="mt-2 text-3xl font-bold text-slate-950">{application.applicantProfile.user.name ?? application.applicantProfile.user.email}</h1>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-700">
                  This page is where Super Admin reviews the application case, checks documents and extracted data, enters missing information,
                  sends follow-up messages, runs system-assisted review, and moves the case to the next workflow stage.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <StatusBadge status={application.status} />
                  {application.aiReviewReports[0] ? <RiskBadge risk={application.aiReviewReports[0].overallRiskLevel} /> : null}
                  {application.aiReviewReports[0] ? <RecommendationBadge recommendation={application.aiReviewReports[0].recommendation} /> : null}
                </div>
              </div>
              <div className="grid min-w-80 gap-2 rounded-2xl border bg-white/85 p-4 text-sm shadow-sm">
                <div><span className="font-semibold">Application ID:</span> {application.id}</div>
                <div><span className="font-semibold">Received/submitted:</span> {dateLabel(application.applicationSubmittedAt ?? application.submittedAt ?? application.firstUploadAt ?? application.applicationCreatedAt)}</div>
                <div><span className="font-semibold">HR review:</span> {label(application.hrReviewQueue?.status)}</div>
                <div><span className="font-semibold">Last action:</span> {dateLabel(application.lastActionAt ?? application.updatedAt)}</div>
              </div>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button asChild><Link href={`/admin/applications/${application.id}/verification`}>Open Verification Workspace</Link></Button>
              <Button asChild variant="outline"><Link href="/admin/hr-review-queue">Back to HR Review Queue</Link></Button>
              <Button asChild variant="outline"><Link href="/admin/applications">All Applications</Link></Button>
            </div>
          </section>

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Card className="border-blue-100 bg-blue-50"><CardHeader><CardTitle>Queue Status</CardTitle></CardHeader><CardContent className="text-2xl font-bold">{label(application.hrReviewQueue?.status)}</CardContent></Card>
            <Card className="border-orange-100 bg-orange-50"><CardHeader><CardTitle>HR Review Items</CardTitle></CardHeader><CardContent className="text-3xl font-bold">{application.validationIssues.length}</CardContent></Card>
            <Card className="border-purple-100 bg-purple-50"><CardHeader><CardTitle>Screening Report</CardTitle></CardHeader><CardContent className="text-2xl font-bold">{application.aiReviewReports[0]?.status === "completed" && application.aiReviewReports[0]?.overallRiskLevel === "incomplete_review" ? "Completed With Issues" : label(application.aiReviewReports[0]?.status ?? "not_run")}</CardContent></Card>
            <Card className="border-emerald-100 bg-emerald-50"><CardHeader><CardTitle>Documents</CardTitle></CardHeader><CardContent className="text-3xl font-bold">{application.documents.length}</CardContent></Card>
          </section>

          <Card className="border-slate-200">
            <CardHeader><CardTitle>What Super Admin Can Do Here</CardTitle></CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {[
                ["Review applicant data", "Check contact details, employment, licenses, references, and documents."],
                ["Complete missing information", "Use the section editor below to enter verified information from the scanned application or document."],
                ["Run system-assisted review", "Generate or rerun the screening report when validation allows it."],
                ["Send applicant follow-up", "Request missing documents or clarification by in-app, email, SMS, or WhatsApp queue."],
                ["Move workflow forward", "Start review, request documents, put on hold, submit to DON, or archive with a required note."],
                ["Open verification", "Move into final verification once the application is approved for that stage."]
              ].map(([title, body]) => (
                <div key={title} className="rounded-xl border bg-slate-50 p-4 text-sm">
                  <p className="font-semibold text-slate-950">{title}</p>
                  <p className="mt-1 text-slate-600">{body}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_420px]">
            <Card>
              <CardHeader><CardTitle>Applicant Case File</CardTitle></CardHeader>
              <CardContent className="grid gap-4 text-sm">
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="rounded-xl border bg-slate-50 p-3"><p className="font-semibold">Name</p><p>{application.applicantProfile.user.name ?? "Not recorded"}</p></div>
                  <div className="rounded-xl border bg-slate-50 p-3"><p className="font-semibold">Email</p><p>{application.applicantProfile.user.email}</p></div>
                  <div className="rounded-xl border bg-slate-50 p-3"><p className="font-semibold">Phone</p><p>{application.applicantProfile.phone ?? "Not recorded"}</p></div>
                  <div className="rounded-xl border bg-slate-50 p-3"><p className="font-semibold">Role applied for</p><p>{application.desiredRole ?? "Not recorded"}</p></div>
                </div>
                <Table>
                  <TableHeader><TableRow><TableHead>Section</TableHead><TableHead>Current records</TableHead></TableRow></TableHeader>
                  <TableBody>
                    <TableRow><TableCell>Employment</TableCell><TableCell>{application.employmentHistory.length}</TableCell></TableRow>
                    <TableRow><TableCell>Licenses</TableCell><TableCell>{application.licenses.length}</TableCell></TableRow>
                    <TableRow><TableCell>Certifications</TableCell><TableCell>{application.certifications.length}</TableCell></TableRow>
                    <TableRow><TableCell>References</TableCell><TableCell>{application.references.length}</TableCell></TableRow>
                    <TableRow><TableCell>Extracted fields</TableCell><TableCell>{application.extractedFields.length}</TableCell></TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Primary Actions</CardTitle></CardHeader>
              <CardContent className="grid gap-4">
                <RunReviewButton applicationId={application.id} hasReport={Boolean(application.aiReviewReports[0])} />
                <Button asChild variant="outline"><Link href={`/admin/applications/${application.id}/verification`}>Open Verification Workspace</Link></Button>
                <Button asChild variant="outline"><Link href="/admin/notifications">Open Notifications</Link></Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader><CardTitle>Missing Information and Section Editing</CardTitle></CardHeader>
            <CardContent>
              <HrMissingInformationEditor applicationId={application.id} issues={application.validationIssues} />
            </CardContent>
          </Card>

          <div className="grid gap-6 xl:grid-cols-2">
            <Card>
              <CardHeader><CardTitle>Workflow Controls</CardTitle></CardHeader>
              <CardContent className="grid gap-5">
                <ApplicationWorkflowControls applicationId={application.id} currentStatus={application.status} />
                <div className="rounded-xl border bg-slate-50 p-3">
                  <p className="font-semibold">HR Decision</p>
                  <p className="mt-1 text-sm text-muted-foreground">Use this for formal HR screening decisions. DON remains final approval authority.</p>
                  <div className="mt-3"><HRDecisionPanel applicationId={application.id} /></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Send Applicant Follow-Up</CardTitle></CardHeader>
              <CardContent>
                <MessageComposer applicationId={application.id} />
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <Card>
              <CardHeader><CardTitle>Uploaded Documents</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {application.documents.map((document) => (
                  <div key={document.id} className="rounded-xl border bg-slate-50 p-3">
                    <p className="font-semibold">{document.fileName}</p>
                    <p className="text-muted-foreground">{label(document.documentType)} / detected {label(document.detectedDocumentType)} / {label(document.processingStatus)}</p>
                    <div className="mt-2"><DocumentPreviewLink documentId={document.id} label="Preview Document" /></div>
                  </div>
                ))}
                {!application.documents.length ? <p className="text-muted-foreground">No documents uploaded.</p> : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Open Issues</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {application.validationIssues.map((issue) => (
                  <div key={issue.id} className="rounded-xl border border-orange-200 bg-orange-50 p-3 text-orange-950">
                    <p className="font-semibold">{issue.section}{issue.fieldKey ? ` - ${issue.fieldKey}` : ""}</p>
                    <p className="mt-1">{issue.message}</p>
                    <p className="mt-1 text-xs">Required action: {issue.requiredAction ?? "Review this item."}</p>
                    <p className="text-xs">Responsible party: {issue.responsibleParty ?? "Applicant or HR"}</p>
                  </div>
                ))}
                {!application.validationIssues.length ? <p className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-emerald-800">No unresolved validation items are currently attached.</p> : null}
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <Card>
              <CardHeader><CardTitle>System Alerts</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {application.systemAlerts.map((alert) => <div key={alert.id} className="rounded-md border bg-slate-50 p-3"><p className="font-semibold">{alert.title}</p><p>{alert.message}</p></div>)}
                {!application.systemAlerts.length ? <p className="text-muted-foreground">No active alerts for this application.</p> : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Recent Activity</CardTitle></CardHeader>
              <CardContent className="grid gap-2 text-sm">
                {application.statusHistory.map((entry) => (
                  <div key={entry.id} className="rounded-md border bg-slate-50 p-3">
                    <p className="font-semibold">{label(entry.fromStatus)} {"->"} {label(entry.toStatus)}</p>
                    <p className="text-muted-foreground">{entry.reason} / {entry.createdAt.toLocaleString()}</p>
                  </div>
                ))}
                {!application.statusHistory.length ? <p className="text-muted-foreground">No status history recorded.</p> : null}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </DashboardShell>
  );
}
