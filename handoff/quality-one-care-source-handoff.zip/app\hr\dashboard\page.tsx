import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { AlertPriorityBadge } from "@/components/AlertPriorityBadge";
import { MetricCard } from "@/components/MetricCard";
import { ProfilePhoto } from "@/components/ProfilePhoto";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getApplicationMetrics } from "@/services/applicationService";
import { getPhase5HrMetrics } from "@/services/dashboard/phase5MetricsService";
import { repairHrReviewWorkflowIntegrity } from "@/services/workflow/hrReviewQueueService";

export default async function HrDashboardPage() {
  const user = await requireRole(["hr", "admin", "super_admin_hr", "don_approver", "executive_view_only"]);
  if (!["don_approver", "executive_view_only"].includes(user.role)) {
    await repairHrReviewWorkflowIntegrity(user.id);
  }
  const metrics = await getApplicationMetrics();
  const phase5Metrics = await getPhase5HrMetrics();
  const [
    finalVerificationsInProgress,
    finalVerificationsReady,
    finalVerificationsReturned,
    expiredVerificationItems,
    pendingHrReview,
    hrReviewStarted,
    verificationPending,
    verificationInProgress,
    readyForDonReview,
    donReview,
    missingDocumentsRequested,
    overdueApplications,
    reviewQueueRows
  ] = await Promise.all([
    prisma.finalVerificationChecklist.count({ where: { status: "in_progress" } }),
    prisma.finalVerificationChecklist.count({ where: { status: "ready_for_don_review" } }),
    prisma.finalVerificationChecklist.count({ where: { status: "returned_for_correction" } }),
    prisma.verificationChecklistItem.count({
      where: {
        OR: [
          { status: "expired" },
          { expirationDate: { lt: new Date() } }
        ]
      }
    }),
    prisma.application.count({ where: { status: "hr_review_pending" } }),
    prisma.application.count({ where: { status: "hr_review_started" } }),
    prisma.application.count({ where: { status: "verification_pending" } }),
    prisma.application.count({ where: { status: "verification_in_progress" } }),
    prisma.application.count({ where: { status: "ready_for_don_review" } }),
    prisma.application.count({ where: { status: "don_review" } }),
    prisma.application.count({ where: { status: "correction_requested" } }),
    prisma.application.count({
      where: {
        status: { in: ["hr_review_pending", "hr_review_started", "verification_pending", "verification_in_progress", "correction_requested"] },
        lastActionAt: { lt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) }
      }
    }),
    prisma.application.findMany({
      where: { status: { in: ["hr_review_pending", "hr_review_started"] } },
      include: {
        applicantProfile: { include: { user: true } },
        validationIssues: { where: { resolved: false, issueType: { in: ["missing", "analysis_failed", "low_confidence"] } } },
        hrReviewQueue: true
      },
      orderBy: [{ status: "asc" }, { applicationSubmittedAt: "desc" }, { updatedAt: "desc" }],
      take: 10
    })
  ]);
  const applications = await prisma.application.findMany({
    include: { applicantProfile: { include: { user: true, documents: { where: { documentType: "profile_photo" }, orderBy: { createdAt: "desc" }, take: 1 } } } },
    orderBy: [{ applicationCreatedAt: "desc" }, { updatedAt: "desc" }],
    take: 12
  });
  const draftCount = await prisma.application.count({ where: { status: "draft" } });

  function ageLabel(date: Date | null | undefined) {
    if (!date) return "-";
    const days = Math.floor((Date.now() - date.getTime()) / (24 * 60 * 60 * 1000));
    if (days <= 0) return "Today";
    return `${days} day${days === 1 ? "" : "s"}`;
  }

  function bottleneck(application: typeof applications[number]) {
    const days = Math.floor((Date.now() - (application.lastActionAt ?? application.updatedAt).getTime()) / (24 * 60 * 60 * 1000));
    if (application.status === "draft" && days > 3) return "Draft stuck";
    if (application.status === "correction_requested" && days > 2) return "Correction overdue";
    if (application.status === "submitted" && days > 1) return "Review overdue";
    if (days > 7) return "Stage aging";
    return "On track";
  }

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/hr/dashboard", label: "Dashboard" },
        { href: "/hr/applications", label: "Applications" },
        { href: "/hr/training", label: "Training" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">HR Dashboard</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Application review overview</h1>
        </section>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <MetricCard label="Total Applications" value={metrics.total} />
          <MetricCard label="Draft Applicants" value={draftCount} />
          <MetricCard label="Pending HR Review" value={pendingHrReview} />
          <MetricCard label="HR Review Started" value={hrReviewStarted} />
          <MetricCard label="Verification Pending" value={verificationPending} />
          <MetricCard label="Verification In Progress" value={verificationInProgress} />
          <MetricCard label="Ready for DON Review" value={readyForDonReview} />
          <MetricCard label="DON Approval Queue" value={donReview + finalVerificationsReady} />
          <MetricCard label="Missing Documents Requested" value={missingDocumentsRequested} />
          <MetricCard label="Overdue Applications" value={overdueApplications} />
          <MetricCard label="Ready for Interview" value={metrics.ready} />
          <MetricCard label="Correction Required" value={metrics.correction} />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>HR Review Work Queue</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applicant Name</TableHead>
                  <TableHead>Application ID</TableHead>
                  <TableHead>Submission Date/Time</TableHead>
                  <TableHead>Current Status</TableHead>
                  <TableHead>Missing Docs</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reviewQueueRows.map((application) => (
                  <TableRow key={application.id}>
                    <TableCell className="font-medium">{application.applicantProfile.user.name ?? application.applicantProfile.user.email}</TableCell>
                    <TableCell className="font-mono text-xs">{application.id}</TableCell>
                    <TableCell>{(application.applicationSubmittedAt ?? application.submittedAt ?? application.updatedAt).toLocaleString()}</TableCell>
                    <TableCell><StatusBadge status={application.status} /></TableCell>
                    <TableCell>{application.validationIssues.length}</TableCell>
                    <TableCell>
                      <Button asChild size="sm">
                        <Link href={application.status === "hr_review_pending" ? `/hr/applications/${application.id}/open-review` : `/hr/applications/${application.id}/review`}>Open Review</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {!reviewQueueRows.length ? <p className="mt-3 text-sm text-muted-foreground">No applications are waiting for HR review.</p> : null}
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Queued Emails" value={phase5Metrics.queuedEmails} />
          <MetricCard label="Scheduled Interviews" value={phase5Metrics.scheduledInterviews} />
          <MetricCard label="Onboarding In Progress" value={phase5Metrics.onboardingInProgress} />
          <MetricCard label="Expired Licenses" value={phase5Metrics.expiredLicenses} />
          <MetricCard label="Expiring Within 30 Days" value={phase5Metrics.expiringLicenses} />
          <MetricCard label="Open License Alerts" value={phase5Metrics.openLicenseAlerts} />
          <MetricCard label="Submitted Over 24h" value={phase5Metrics.overdueSubmittedReviews} />
          <MetricCard label="Failed Job Runs" value={phase5Metrics.failedJobs} />
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Final Verifications In Progress" value={finalVerificationsInProgress} />
          <MetricCard label="Ready for DON Review" value={finalVerificationsReady} />
          <MetricCard label="Returned for Correction" value={finalVerificationsReturned} />
          <MetricCard label="Expired Verification Items" value={expiredVerificationItems} />
        </div>

        <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>Applicant Lifecycle Monitor</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Applicant Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Started</TableHead>
                    <TableHead>Stage Age</TableHead>
                    <TableHead>Bottleneck</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.map((application) => (
                    <TableRow key={application.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <ProfilePhoto document={application.applicantProfile.documents[0]} viewerUserId={user.id} name={application.applicantProfile.user.name ?? application.applicantProfile.user.email} size="sm" />
                          <Link className="font-medium text-orange-700 hover:underline" href={`/hr/applicants/${application.applicantProfileId}`}>
                            {application.applicantProfile.user.name ?? application.applicantProfile.user.email}
                          </Link>
                        </div>
                      </TableCell>
                      <TableCell><StatusBadge status={application.status} /></TableCell>
                      <TableCell>{application.applicationCreatedAt.toLocaleDateString()}</TableCell>
                      <TableCell>{ageLabel(application.lastActionAt ?? application.applicationCreatedAt)}</TableCell>
                      <TableCell>{bottleneck(application)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Prioritized Alerts</CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link href="/hr/applications">Review Queue</Link>
              </Button>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm">
              {phase5Metrics.activeAlerts.length ? phase5Metrics.activeAlerts.map((alert) => (
                <div key={alert.id} className="rounded-md border bg-slate-50 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <AlertPriorityBadge priority={alert.priority} />
                    <p className="font-medium">{alert.title}</p>
                  </div>
                  <p className="mt-2 text-slate-700">{alert.message}</p>
                  {alert.route ? (
                    <Button asChild variant="outline" size="sm" className="mt-3">
                      <Link href={alert.route}>Open</Link>
                    </Button>
                  ) : null}
                </div>
              )) : <p className="text-muted-foreground">No active operational alerts.</p>}
              <div className="grid gap-2 rounded-md border border-dashed p-3">
                <p className="font-medium">Automation watchlist</p>
                <p>Drafts inactive over 3 days: {phase5Metrics.staleDrafts}</p>
                <p>Correction requests inactive over 2 days: {phase5Metrics.staleCorrections}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}
