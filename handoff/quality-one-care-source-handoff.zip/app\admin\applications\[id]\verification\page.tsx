import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { StageGateActionButtons } from "@/components/StageGateActionButtons";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { adminNav } from "@/lib/adminNav";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getVerificationChecklist, summarizeChecklist } from "@/services/verification/verificationService";
import { repairHrReviewWorkflowIntegrity } from "@/services/workflow/hrReviewQueueService";

function label(value: string | null | undefined) {
  if (!value) return "Not recorded";
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function dateLabel(date: Date | null | undefined) {
  return date ? date.toLocaleString() : "Not recorded";
}

function reviewerPurpose(status: string) {
  if (["hr_review_pending", "submitted"].includes(status)) {
    return "Super Admin should confirm the submitted application is visible, then start HR review and assign follow-up work.";
  }
  if (["hr_review_started", "under_review"].includes(status)) {
    return "Super Admin should review applicant data, uploaded documents, unresolved intake issues, review task ownership, and decide whether HR can move the application toward verification.";
  }
  if (["verification_pending", "verification_in_progress"].includes(status)) {
    return "Super Admin should monitor checklist completion, missing evidence, expired credentials, and HR verification activity.";
  }
  if (["ready_for_don_review", "don_review"].includes(status)) {
    return "Super Admin should confirm HR verification is complete and the case is ready for the DON final approval decision.";
  }
  return "Super Admin should review the application status, activity history, documents, and next operational action.";
}

export default async function AdminApplicationVerificationPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireRole(["admin", "super_admin_hr", "executive_view_only"]);
  const { id } = await params;

  await repairHrReviewWorkflowIntegrity(user.id);

  const application = await prisma.application.findUnique({
    where: { id },
    include: {
      applicantProfile: { include: { user: true } },
      documents: { orderBy: { createdAt: "desc" } },
      extractedFields: { orderBy: { createdAt: "desc" }, take: 12 },
      validationIssues: { where: { resolved: false }, orderBy: { createdAt: "desc" } },
      fieldAssertions: { include: { sourceDocument: true }, orderBy: { createdAt: "desc" } },
      hrReviewQueue: true,
      tasks: { orderBy: { createdAt: "desc" }, take: 8 },
      applicantMessages: { orderBy: { createdAt: "desc" }, take: 8 },
      systemAlerts: { where: { resolved: false }, orderBy: { createdAt: "desc" }, take: 8 },
      aiReviewReports: { orderBy: { createdAt: "desc" }, take: 1, include: { findings: true } },
      decisions: { orderBy: { createdAt: "desc" }, take: 1 },
      statusHistory: { include: { changedBy: true }, orderBy: { createdAt: "desc" }, take: 10 },
      licenses: true,
      employmentHistory: true,
      references: true,
      certifications: true,
      finalVerificationChecklist: { include: { items: { orderBy: { createdAt: "asc" } } } }
    }
  });

  if (!application) {
    return (
      <DashboardShell user={user} nav={adminNav}>
        <Card><CardContent className="p-6">Application not found.</CardContent></Card>
      </DashboardShell>
    );
  }

  const checklist = await getVerificationChecklist(application.id);
  const checklistSummary = checklist ? summarizeChecklist(checklist) : null;
  const applicant = application.applicantProfile.user;
  const applicantName = applicant.name ?? applicant.email;
  const latestReport = application.aiReviewReports[0];
  const latestDecision = application.decisions[0];
  const auditLogs = await prisma.auditLog.findMany({
    where: {
      OR: [
        { entityId: application.id },
        { entityId: { in: application.documents.map((document) => document.id) } },
        { entityId: { in: application.validationIssues.map((issue) => issue.id) } }
      ]
    },
    include: { user: true },
    orderBy: { createdAt: "desc" },
    take: 12
  });

  const unresolvedBlocking = application.validationIssues.filter((issue) => issue.severity === "blocking").length;
  const missingOrUnclear = application.validationIssues.filter((issue) => ["missing", "low_confidence", "analysis_failed", "mismatch"].includes(issue.issueType)).length;
  const openTasks = application.tasks.filter((task) => ["open", "in_progress", "overdue"].includes(task.status));
  const reviewChecklist = [
    { label: "Applicant identity and contact", value: `${applicantName} / ${applicant.email} / ${application.applicantProfile.phone ?? "No phone"}` },
    { label: "Uploaded documents", value: `${application.documents.length} document${application.documents.length === 1 ? "" : "s"} uploaded` },
    { label: "Unresolved intake issues", value: `${application.validationIssues.length} active issue${application.validationIssues.length === 1 ? "" : "s"}` },
    { label: "Field extraction", value: `${application.extractedFields.length} recent extracted field${application.extractedFields.length === 1 ? "" : "s"}` },
    { label: "HR review task", value: application.hrReviewQueue ? `Queue ${label(application.hrReviewQueue.status)}` : "No queue record" },
    { label: "Final verification", value: checklist ? `${checklistSummary?.completionPercentage ?? 0}% complete` : "Not created yet because this application is not approved for final verification" }
  ];
  const criticalFindings = latestReport?.findings.filter((finding) => finding.severity === "critical") ?? [];
  const concernFindings = latestReport?.findings.filter((finding) => finding.severity === "concern") ?? [];
  const findingSummary = [...criticalFindings, ...concernFindings].map((finding) => finding.title).join("; ");

  return (
    <DashboardShell user={user} nav={adminNav}>
      <div className="grid gap-6">
        <section className="rounded-2xl border border-blue-200 bg-gradient-to-br from-white via-blue-50 to-orange-50 p-6 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Super Admin Review Workspace</p>
              <h1 className="mt-2 text-3xl font-bold text-slate-950">{applicantName}</h1>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-700">{reviewerPurpose(application.status)}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <StatusBadge status={application.status} />
                <span className="rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">Application ID: {application.id}</span>
              </div>
            </div>
            <div className="grid min-w-72 gap-2 rounded-2xl border bg-white/85 p-4 text-sm shadow-sm">
              <div><span className="font-semibold">Submitted:</span> {dateLabel(application.applicationSubmittedAt ?? application.submittedAt)}</div>
              <div><span className="font-semibold">HR review started:</span> {dateLabel(application.hrReviewStartedAt)}</div>
              <div><span className="font-semibold">Last action:</span> {dateLabel(application.lastActionAt ?? application.updatedAt)}</div>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button asChild><Link href={`/admin/applications/${application.id}/review`}>Open HR Review</Link></Button>
            <Button asChild variant="outline"><Link href="/admin/hr-review-queue">Back to HR Review Queue</Link></Button>
            {checklist ? <Button asChild variant="outline"><Link href={`/don/final-approval/${application.id}`}>Open DON Report</Link></Button> : null}
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <Card className="border-blue-100 bg-blue-50"><CardHeader><CardTitle className="text-sm">Documents Uploaded</CardTitle></CardHeader><CardContent className="text-3xl font-bold">{application.documents.length}</CardContent></Card>
          <Card className="border-orange-100 bg-orange-50"><CardHeader><CardTitle className="text-sm">Missing / Unclear</CardTitle></CardHeader><CardContent className="text-3xl font-bold">{missingOrUnclear}</CardContent></Card>
          <Card className="border-red-100 bg-red-50"><CardHeader><CardTitle className="text-sm">Blocking Issues</CardTitle></CardHeader><CardContent className="text-3xl font-bold">{unresolvedBlocking}</CardContent></Card>
          <Card className="border-purple-100 bg-purple-50"><CardHeader><CardTitle className="text-sm">Open Staff Tasks</CardTitle></CardHeader><CardContent className="text-3xl font-bold">{openTasks.length}</CardContent></Card>
        </section>

        <Card className={criticalFindings.length || concernFindings.length ? "border-red-200 bg-red-50" : "border-emerald-200 bg-emerald-50"}>
          <CardHeader>
            <CardTitle>Stage Gate: What Must Happen Next</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 text-sm">
            {criticalFindings.length || concernFindings.length ? (
              <>
                <div className="rounded-xl border border-red-200 bg-white p-4">
                  <p className="font-semibold text-red-900">This application cannot move to final verification yet.</p>
                  <p className="mt-1 text-red-800">
                    The current status is {label(application.status)} because system-assisted review found compliance issues that must be resolved, overridden with justification where allowed, or used as the basis for rejection.
                  </p>
                </div>
                <div className="grid gap-2">
                  {[...criticalFindings, ...concernFindings].map((finding) => (
                    <div key={finding.id} className="rounded-xl border bg-white p-3">
                      <p className="font-semibold text-slate-950">{finding.title}</p>
                      <p className="mt-1 text-slate-700">{finding.description}</p>
                      <p className="mt-1 text-xs font-semibold uppercase tracking-wide text-red-700">{label(finding.severity)} / {label(finding.category)}</p>
                    </div>
                  ))}
                </div>
                <div className="grid gap-3 rounded-xl border border-orange-200 bg-orange-50 p-4 text-orange-950">
                  <p className="font-semibold">Super Admin options at this point</p>
                  <p>1. Request applicant correction/missing documents if the applicant must supply evidence.</p>
                  <p>2. Go to HR Review Workspace, enter missing verified information, add HR notes/override justification, then rerun review.</p>
                  <p>3. Reject at HR screening if required evidence cannot be provided or the application is unsuitable.</p>
                </div>
                <StageGateActionButtons
                  applicationId={application.id}
                  defaultNote={`The application cannot proceed until these items are resolved: ${findingSummary || "compliance review findings"}. Please provide the missing evidence or clarification.`}
                />
              </>
            ) : (
              <div className="rounded-xl border border-emerald-200 bg-white p-4 text-emerald-900">
                No critical or concern-level analysis findings are currently attached. If HR review is complete, proceed through the HR Review Workspace to move this case toward verification.
              </div>
            )}
            <div className="flex flex-wrap gap-2">
              <Button asChild><Link href={`/admin/applications/${application.id}/review`}>Go to HR Review Workspace</Link></Button>
              <Button asChild variant="outline"><Link href="/admin/hr-review-queue">Back to HR Review Queue</Link></Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader><CardTitle>Exactly What Super Admin Should Review Here</CardTitle></CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2">
            {reviewChecklist.map((item) => (
              <div key={item.label} className="rounded-xl border bg-slate-50 p-4">
                <div className="text-sm font-semibold text-slate-950">{item.label}</div>
                <div className="mt-1 text-sm text-slate-600">{item.value}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        {!checklist ? (
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader><CardTitle>Final Verification Is Not Ready Yet</CardTitle></CardHeader>
            <CardContent className="grid gap-3 text-sm text-orange-950">
              <p>
                This is why the previous page looked empty: final employment verification checklist is created after HR approves the application for final verification/onboarding. This applicant is currently at <span className="font-semibold">{label(application.status)}</span>.
              </p>
              <p>The meaningful review right now is HR intake review: submitted data, documents, extracted fields, missing/unclear issues, messages, and task ownership.</p>
              <div><Button asChild><Link href={`/admin/applications/${application.id}/review`}>Go to HR Review Workspace</Link></Button></div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader><CardTitle>Final Verification Checklist</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader><TableRow><TableHead>Item</TableHead><TableHead>Status</TableHead><TableHead>Result</TableHead><TableHead>Evidence</TableHead><TableHead>Notes</TableHead></TableRow></TableHeader>
                <TableBody>
                  {checklist.items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.title}</TableCell>
                      <TableCell>{label(item.status)}</TableCell>
                      <TableCell>{item.result ?? "-"}</TableCell>
                      <TableCell>{item.document?.fileName ?? "-"}</TableCell>
                      <TableCell>{item.notes ?? "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-6 xl:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Uploaded Documents</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {application.documents.map((document) => (
                <div key={document.id} className="rounded-xl border bg-white p-3">
                  <div className="font-semibold">{document.fileName}</div>
                  <div className="mt-1 text-slate-600">{label(document.documentType)} / detected {label(document.detectedDocumentType)} / {label(document.processingStatus)}</div>
                  <div className="mt-1 text-xs text-slate-500">Uploaded {document.createdAt.toLocaleString()}</div>
                </div>
              ))}
              {!application.documents.length ? <p className="text-muted-foreground">No uploaded documents are attached to this application yet.</p> : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Unresolved Issues</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {application.validationIssues.map((issue) => (
                <div key={issue.id} className="rounded-xl border bg-white p-3">
                  <div className="font-semibold">{issue.message}</div>
                  <div className="mt-1 text-slate-600">Field: {issue.fieldKey ?? "General"} / {label(issue.severity)} / {label(issue.issueType)}</div>
                  {issue.reason ? <div className="mt-1 text-xs text-slate-500">Reason: {issue.reason}</div> : null}
                  {issue.requiredAction ? <div className="mt-1 text-xs text-slate-500">Required action: {issue.requiredAction}</div> : null}
                </div>
              ))}
              {!application.validationIssues.length ? <p className="text-muted-foreground">No unresolved validation issues are attached.</p> : null}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 xl:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Recent Extracted Fields</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader><TableRow><TableHead>Field</TableHead><TableHead>Value</TableHead><TableHead>Confidence</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
                <TableBody>
                  {application.extractedFields.map((field) => (
                    <TableRow key={field.id}>
                      <TableCell>{field.fieldLabel}</TableCell>
                      <TableCell>{field.applicantCorrectedValue ?? field.extractedValue}</TableCell>
                      <TableCell>{Math.round(field.confidence * 100)}%</TableCell>
                      <TableCell>{label(field.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {!application.extractedFields.length ? <p className="text-sm text-muted-foreground">No extracted fields are available yet.</p> : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Tasks, Alerts, and Messages</CardTitle></CardHeader>
            <CardContent className="grid gap-3 text-sm">
              <div>
                <div className="font-semibold text-slate-950">Open tasks</div>
                {application.tasks.map((task) => <p key={task.id} className="mt-1 text-slate-600">{task.title} - {label(task.status)}</p>)}
                {!application.tasks.length ? <p className="text-slate-500">No tasks recorded.</p> : null}
              </div>
              <div>
                <div className="font-semibold text-slate-950">Active alerts</div>
                {application.systemAlerts.map((alert) => <p key={alert.id} className="mt-1 text-slate-600">{alert.title} - {label(alert.priority)}</p>)}
                {!application.systemAlerts.length ? <p className="text-slate-500">No active alerts.</p> : null}
              </div>
              <div>
                <div className="font-semibold text-slate-950">Recent messages</div>
                {application.applicantMessages.map((message) => <p key={message.id} className="mt-1 text-slate-600">{message.subject} - {message.createdAt.toLocaleString()}</p>)}
                {!application.applicantMessages.length ? <p className="text-slate-500">No messages recorded.</p> : null}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 xl:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Status Timeline</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {application.statusHistory.map((history) => (
                <div key={history.id} className="rounded-xl border bg-slate-50 p-3">
                  <div className="font-semibold">{label(history.fromStatus)} {"->"} {label(history.toStatus)}</div>
                  <div className="text-xs text-slate-500">{history.reason} / {history.createdAt.toLocaleString()} / {history.changedBy?.name ?? history.changedBy?.email ?? "System"}</div>
                </div>
              ))}
              {!application.statusHistory.length ? <p className="text-muted-foreground">No status history recorded.</p> : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Audit Trail</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {auditLogs.map((entry) => (
                <div key={entry.id} className="rounded-xl border bg-slate-50 p-3">
                  <div className="font-semibold">{entry.action}</div>
                  <div className="text-xs text-slate-500">{entry.entityType} / {entry.entityId ?? "n/a"} / {entry.createdAt.toLocaleString()} / {entry.user?.name ?? entry.user?.email ?? "System"}</div>
                </div>
              ))}
              {!auditLogs.length ? <p className="text-muted-foreground">No audit entries found for this case yet.</p> : null}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}
