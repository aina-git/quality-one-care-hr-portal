import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function label(value: string) {
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

export default async function HrTrainingPage() {
  const user = await requireRole(["hr", "admin", "super_admin_hr", "executive_view_only"]);
  const recommendations = await prisma.trainingRecommendation.findMany({
    include: {
      application: {
        include: {
          applicantProfile: { include: { user: true } },
          employeeOnboarding: true
        }
      }
    },
    orderBy: [{ priority: "desc" }, { createdAt: "desc" }],
    take: 100
  });
  const recommended = recommendations.filter((item) => item.status === "recommended").length;
  const assigned = recommendations.filter((item) => item.status === "assigned").length;
  const completed = recommendations.filter((item) => item.status === "completed").length;

  return (
    <DashboardShell user={user} nav={[{ href: "/hr/dashboard", label: "Dashboard" }, { href: "/hr/applications", label: "Applications" }, { href: "/hr/training", label: "Training" }]}>
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Training Dashboard</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Machine-learning-assisted training recommendations</h1>
        </section>

        <div className="grid gap-4 sm:grid-cols-3">
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Recommended</CardTitle></CardHeader><CardContent><div className="text-3xl font-semibold">{recommended}</div></CardContent></Card>
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Assigned</CardTitle></CardHeader><CardContent><div className="text-3xl font-semibold">{assigned}</div></CardContent></Card>
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Completed</CardTitle></CardHeader><CardContent><div className="text-3xl font-semibold">{completed}</div></CardContent></Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Recommendations</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applicant</TableHead>
                  <TableHead>Training</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Onboarding</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recommendations.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.application.applicantProfile.user.name ?? item.application.applicantProfile.user.email}</TableCell>
                    <TableCell>{item.trainingTitle}</TableCell>
                    <TableCell>{label(item.priority)}</TableCell>
                    <TableCell>{label(item.status)}</TableCell>
                    <TableCell>{item.reason}</TableCell>
                    <TableCell>{item.application.employeeOnboarding ? <Button asChild size="sm" variant="outline"><Link href={`/hr/onboarding/${item.application.employeeOnboarding.id}`}>Open</Link></Button> : "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
