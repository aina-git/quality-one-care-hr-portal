import Link from "next/link";
import { CheckCircle2 } from "lucide-react";
import { ApplicantProgressTimeline } from "@/components/ApplicantProgressTimeline";
import { DashboardShell } from "@/components/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResubmitApplicationButton } from "@/components/ResubmitApplicationButton";
import { ProfilePhoto } from "@/components/ProfilePhoto";
import { StatusBadge } from "@/components/StatusBadge";
import { SubmitApplicationButton } from "@/components/SubmitApplicationButton";
import { ValidationChecklist } from "@/components/ValidationChecklist";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { applicationSections, getLatestApplicantApplication } from "@/services/applicationService";
import { validateApplication } from "@/services/validation/applicationValidationService";
import { getApplicationProgress } from "@/services/applicantProgressService";

export default async function ApplicantDashboardPage() {
  const user = await requireRole(["applicant"]);
  const { application } = await getLatestApplicantApplication(user.id);
  if (!application) {
    return (
      <DashboardShell
        user={user}
        nav={[
          { href: "/applicant/dashboard", label: "Dashboard" },
          { href: "/applicant/start", label: "Begin Intake" },
          { href: "/applicant/application", label: "Application" },
          { href: "/applicant/messages", label: "Messages" }
        ]}
      >
        <div className="grid gap-6">
          <section className="rounded-2xl border bg-white p-6 shadow-sm">
            <p className="text-sm font-semibold text-orange-600">Applicant Portal</p>
            <h1 className="mt-2 text-3xl font-semibold">Start your application first</h1>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
              Create your draft application record before uploading documents or using intake tools.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Button asChild><Link href="/applicant/application">Start Application</Link></Button>
              <Button asChild variant="outline"><Link href="/applicant/start">View Intake Options</Link></Button>
            </div>
          </section>
        </div>
      </DashboardShell>
    );
  }
  const documents = await prisma.uploadedDocument.findMany({ where: { applicationId: application.id } });
  const pendingFields = await prisma.extractedField.count({ where: { applicationId: application.id, status: "pending_review" } });
  const messages = await prisma.applicantMessage.findMany({
    where: { applicationId: application.id, visibleToApplicant: true },
    orderBy: { createdAt: "desc" },
    take: 3
  });
  const interviews = await prisma.interviewRecord.findMany({
    where: { applicationId: application.id },
    orderBy: [{ scheduledAt: "asc" }, { createdAt: "desc" }],
    take: 3
  });
  const onboardingChecklist = await prisma.onboardingChecklist.findUnique({
    where: { applicationId: application.id },
    include: { items: { orderBy: { createdAt: "asc" } } }
  });
  const openLicenseAlerts = await prisma.licenseAlert.findMany({
    where: { applicationId: application.id, resolved: false },
    orderBy: { createdAt: "desc" },
    take: 3
  });
  const validation = await validateApplication(application.id, user.id);
  const applicantPendingItems = [...validation.blockingIssues, ...validation.warningIssues].filter((issue) =>
    ["Applicant", "HR"].includes(issue.responsibleParty ?? "Applicant") || issue.applicantActionStatus
  );
  const extractionComplete = documents.length > 0 && documents.every((doc) => doc.processingStatus === "completed");
  const fieldsReviewed = pendingFields === 0;
  const onboardingItems = onboardingChecklist?.items ?? [];
  const completedOnboardingItems = onboardingItems.filter((item) => item.status !== "pending").length;
  const automatedMessages = messages.filter((message) => message.senderRole === "system").length;
  const hasDocumentUploads = documents.length > 0 && application.status === "draft";
  const progress = await getApplicationProgress(application.id);
  const profilePhoto = await prisma.uploadedDocument.findFirst({
    where: { applicantProfileId: application.applicantProfileId, documentType: "profile_photo" },
    orderBy: { createdAt: "desc" }
  });

  return (
    <DashboardShell
      user={user}
      nav={[
        { href: "/applicant/dashboard", label: "Dashboard" },
        { href: "/applicant/application", label: "Application" },
        { href: "/applicant/intake-review", label: "Intake Review" },
        { href: "/applicant/messages", label: "Messages" },
        { href: "/applicant/onboarding", label: "Onboarding" }
      ]}
    >
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <div className="flex flex-wrap items-center gap-4">
            <ProfilePhoto document={profilePhoto} viewerUserId={user.id} name={user.name ?? user.email} />
            <div>
              <p className="text-sm font-medium text-orange-600">Applicant Portal</p>
              <h1 className="mt-2 text-3xl font-semibold tracking-normal">Welcome, {user.name ?? "Applicant"}</h1>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <span className="text-sm text-muted-foreground">Application status:</span>
            <StatusBadge status={application.status} />
          </div>
          <Button asChild className="mt-6">
            <Link href="/applicant/application">Continue Application</Link>
          </Button>
        </section>

        {application.status === "correction_requested" && (
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle>Correction Requested</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm text-orange-900">
              <p>HR requested clarification before your application can continue. Review your messages, update the needed information, then resubmit when validation passes.</p>
              {messages[0] && (
                <div className="rounded-md border border-orange-200 bg-white p-3">
                  <p className="font-medium">{messages[0].subject}</p>
                  <p className="mt-1">{messages[0].body}</p>
                </div>
              )}
              <div className="flex flex-wrap gap-3">
                <Button asChild variant="outline"><Link href="/applicant/messages">View Messages</Link></Button>
                <Button asChild variant="outline"><Link href="/applicant/application">Update Application</Link></Button>
              </div>
            </CardContent>
          </Card>
        )}

        {hasDocumentUploads && (
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle>Documents Received</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm text-orange-900">
              <p>We received your documents. Please review extracted information and complete the remaining required fields.</p>
              <div className="flex flex-wrap gap-3">
                <Button asChild variant="outline"><Link href="/applicant/intake-status">View Intake Status</Link></Button>
                <Button asChild variant="outline"><Link href="/applicant/intake-review">Review Extracted Fields</Link></Button>
                <Button asChild><Link href="/applicant/application">Continue Application</Link></Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className={applicantPendingItems.length ? "border-orange-200 bg-orange-50" : "border-blue-200 bg-blue-50"}>
          <CardHeader>
            <CardTitle>Pending Items and Follow-Up</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm">
            {applicantPendingItems.length ? (
              <>
                <p className="text-orange-950">
                  These are the items still being completed, reviewed by HR, or waiting for your action. If something is already in your scanned application, send it to HR review from Intake Status.
                </p>
                <div className="grid gap-2">
                  {applicantPendingItems.slice(0, 6).map((issue) => (
                    <div key={issue.id} className="rounded-xl border border-orange-200 bg-white p-3">
                      <p className="font-semibold text-slate-950">{issue.section}{issue.fieldKey ? ` - ${issue.fieldKey}` : ""}</p>
                      <p className="mt-1 text-slate-700">{issue.message}</p>
                      <p className="mt-1 text-xs text-orange-800">Required action: {issue.requiredAction ?? "Review this item."}</p>
                      <p className="text-xs text-orange-800">Responsible party: {issue.responsibleParty ?? "Applicant"}</p>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button asChild variant="outline"><Link href="/applicant/intake-status">Open Intake Status</Link></Button>
                  <Button asChild variant="outline"><Link href="/applicant/intake-review">Review Extracted Fields</Link></Button>
                  <Button asChild><Link href="/applicant/application">Continue Application</Link></Button>
                </div>
              </>
            ) : (
              <p className="text-blue-950">
                No applicant correction is required right now. Current workflow status: {application.status.replace(/_/g, " ")}. If HR needs anything from you, it will appear here and in Messages.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          {[
            ["Documents uploaded", documents.length > 0],
            ["Extraction complete", extractionComplete],
            ["Fields reviewed", fieldsReviewed],
            ["Validation complete", validation.blockingIssues.length === 0],
            ["Ready to submit", validation.canSubmit]
          ].map(([label, complete]) => (
            <div key={String(label)} className="rounded-lg border bg-white p-4 shadow-sm">
              <p className="text-sm font-medium">{label}</p>
              <p className={complete ? "mt-2 text-sm text-green-700" : "mt-2 text-sm text-orange-700"}>{complete ? "Complete" : "Needs attention"}</p>
            </div>
          ))}
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <p className="text-sm font-medium">Applicant Messages</p>
            <p className="mt-2 text-2xl font-semibold text-slate-950">{messages.length}</p>
            <p className="mt-1 text-sm text-muted-foreground">{automatedMessages} automated reminder(s)</p>
          </div>
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <p className="text-sm font-medium">Interview Records</p>
            <p className="mt-2 text-2xl font-semibold text-slate-950">{interviews.length}</p>
            <p className="mt-1 text-sm text-muted-foreground">{interviews[0]?.status ? `Latest status: ${interviews[0].status.replace(/_/g, " ")}` : "No interview scheduled yet"}</p>
          </div>
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <p className="text-sm font-medium">Onboarding Progress</p>
            <p className="mt-2 text-2xl font-semibold text-slate-950">{onboardingItems.length ? `${completedOnboardingItems}/${onboardingItems.length}` : "0/0"}</p>
            <p className="mt-1 text-sm text-muted-foreground">{onboardingChecklist ? onboardingChecklist.status.replace(/_/g, " ") : "Not started"}</p>
          </div>
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <p className="text-sm font-medium">License Alerts</p>
            <p className="mt-2 text-2xl font-semibold text-slate-950">{openLicenseAlerts.length}</p>
            <p className="mt-1 text-sm text-muted-foreground">{openLicenseAlerts.length ? "Please review your messages for details." : "No active alerts"}</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Progress Tracker</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {applicationSections.map((section) => (
              <div key={section} className="flex items-center gap-3 rounded-md border bg-slate-50 p-3">
                <CheckCircle2 className="h-5 w-5 text-orange-500" />
                <span className="text-sm font-medium">{section}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Next Steps</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Button asChild variant="outline"><Link href="/applicant/application">Upload Documents</Link></Button>
            <Button asChild variant="outline"><Link href="/applicant/quick-upload">Upload Documents</Link></Button>
            <Button asChild variant="outline"><Link href="/applicant/intake-status">Intake Status</Link></Button>
            <Button asChild variant="outline"><Link href="/applicant/intake-review">Intake Review</Link></Button>
            <Button asChild variant="outline"><Link href="/applicant/messages">Messages</Link></Button>
            <Button asChild variant="outline"><Link href="/applicant/progress">Application Progress</Link></Button>
            <Button asChild><Link href="/applicant/application">Continue Application</Link></Button>
          </CardContent>
        </Card>

        {progress && (
          <Card>
            <CardHeader>
              <CardTitle>Application Progress</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="rounded-xl border border-blue-100 bg-blue-50 p-3 text-sm text-blue-950">
                <p className="font-semibold">Current stage: {progress.activeStage.label}</p>
                <p className="mt-1">Next step: {progress.nextActionRequired}</p>
              </div>
              <ApplicantProgressTimeline stages={progress.stages} compact />
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4 lg:grid-cols-3">
          <Card>
            <CardHeader><CardTitle>Messages</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {messages.length ? messages.map((message) => (
                <div key={message.id} className="rounded-md border bg-slate-50 p-3">
                  <p className="font-medium">{message.subject}</p>
                  <p className="mt-1 text-muted-foreground">{message.body}</p>
                </div>
              )) : <p className="text-muted-foreground">No messages yet.</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Interview</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {interviews.length ? interviews.map((interview) => (
                <div key={interview.id} className="rounded-md border bg-slate-50 p-3">
                  <p className="font-medium capitalize">{interview.status}</p>
                  <p className="text-muted-foreground">{interview.scheduledAt ? interview.scheduledAt.toLocaleString() : "Time not scheduled"}</p>
                  {interview.location && <p>{interview.location}</p>}
                  {interview.notes && <p className="text-muted-foreground">{interview.notes}</p>}
                </div>
              )) : <p className="text-muted-foreground">No interview has been scheduled yet.</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Onboarding</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {onboardingChecklist ? (
                <>
                  <p className="font-medium">{completedOnboardingItems} of {onboardingItems.length} items complete or waived</p>
                  <div className="h-2 rounded-full bg-slate-100">
                    <div
                      className="h-2 rounded-full bg-orange-500"
                      style={{ width: `${onboardingItems.length ? Math.round((completedOnboardingItems / onboardingItems.length) * 100) : 0}%` }}
                    />
                  </div>
                  {onboardingItems.map((item) => (
                    <div key={item.id} className="rounded-md border bg-slate-50 p-2">
                      <p className="font-medium">{item.title}</p>
                      <p className="capitalize text-muted-foreground">{item.status.replace(/_/g, " ")}</p>
                    </div>
                  ))}
                </>
              ) : <p className="text-muted-foreground">Onboarding will appear here after HR approval.</p>}
            </CardContent>
          </Card>
        </div>

        {openLicenseAlerts.length > 0 && (
          <Card>
            <CardHeader><CardTitle>License Alerts</CardTitle></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              {openLicenseAlerts.map((alert) => (
                <div key={alert.id} className="rounded-md border border-orange-200 bg-orange-50 p-3 text-orange-900">
                  <p className="font-medium capitalize">{alert.alertType.replace(/_/g, " ")}</p>
                  <p>{alert.message}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <ValidationChecklist {...validation} documents={documents.map((document) => ({ id: document.id, fileName: document.fileName, documentType: document.documentType }))} />
        {application.status === "correction_requested" ? (
          <ResubmitApplicationButton canShow={validation.canSubmit} />
        ) : (
          <SubmitApplicationButton canSubmit={validation.canSubmit} />
        )}
      </div>
    </DashboardShell>
  );
}
