import Link from "next/link";
import { redirect } from "next/navigation";
import { DashboardShell } from "@/components/DashboardShell";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireRole } from "@/lib/auth";
import { buildPagination } from "@/lib/security";
import { prisma } from "@/lib/prisma";
import { getLatestApplicantApplication } from "@/services/applicationService";

const applicantNav = [
  { href: "/applicant/dashboard", label: "Dashboard" },
  { href: "/applicant/application", label: "Application" },
  { href: "/applicant/intake-review", label: "Intake Review" },
  { href: "/applicant/messages", label: "Messages" }
];

export default async function ApplicantMessagesPage({
  searchParams
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const user = await requireRole(["applicant"]);
  const params = await searchParams;
  const { application } = await getLatestApplicantApplication(user.id);
  if (!application) redirect("/applicant/application");
  const { page, pageSize, skip, take } = buildPagination(params.page, 10, 10, 25);
  const [total, messages] = await Promise.all([
    prisma.applicantMessage.count({ where: { applicationId: application.id, visibleToApplicant: true } }),
    prisma.applicantMessage.findMany({
      where: { applicationId: application.id, visibleToApplicant: true },
      orderBy: { createdAt: "desc" },
      skip,
      take
    })
  ]);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <DashboardShell user={user} nav={applicantNav}>
      <div className="grid gap-6">
        <section className="rounded-lg border bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-orange-600">Applicant Messages</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-normal">Messages from HR</h1>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <span className="text-sm text-muted-foreground">Application status:</span>
            <StatusBadge status={application.status} />
          </div>
        </section>

        <Card>
          <CardHeader><CardTitle>Inbox</CardTitle></CardHeader>
          <CardContent className="grid gap-3">
            {messages.length ? messages.map((message) => (
              <div key={message.id} className="rounded-md border bg-slate-50 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-medium">{message.subject}</p>
                  <p className="text-xs text-muted-foreground">{message.createdAt.toLocaleDateString()}</p>
                </div>
                <p className="mt-2 text-sm text-slate-700">{message.body}</p>
              </div>
            )) : <p className="text-sm text-muted-foreground">No applicant-visible messages yet.</p>}
            <div className="flex items-center justify-between text-sm">
              <p className="text-muted-foreground">Page {page} of {totalPages}</p>
              <div className="flex gap-2">
                <Button asChild size="sm" variant="outline">
                  <Link href={page > 1 ? `/applicant/messages?page=${page - 1}` : "/applicant/messages"}>Previous</Link>
                </Button>
                <Button asChild size="sm" variant="outline">
                  <Link href={page < totalPages ? `/applicant/messages?page=${page + 1}` : `/applicant/messages?page=${totalPages}`}>Next</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {application.status === "correction_requested" && (
          <Card>
            <CardHeader><CardTitle>Correction Requested</CardTitle></CardHeader>
            <CardContent className="flex flex-wrap gap-3">
              <Button asChild><Link href="/applicant/application">Update Application</Link></Button>
              <Button asChild variant="outline"><Link href="/applicant/intake-review">Review Extracted Fields</Link></Button>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardShell>
  );
}
