import Link from "next/link";
import { FileStack, ScanLine } from "lucide-react";
import { QuickCredentialUploadForm } from "@/components/QuickCredentialUploadForm";
import { DashboardShell } from "@/components/DashboardShell";
import { OperationalPulse } from "@/components/OperationalPulse";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getLatestApplicantApplication } from "@/services/applicationService";
import { redirect } from "next/navigation";

function metadata(doc: { metadataJson: unknown }) {
  return doc.metadataJson && typeof doc.metadataJson === "object" && !Array.isArray(doc.metadataJson)
    ? doc.metadataJson as Record<string, unknown>
    : {};
}

export default async function QuickUploadPage({
  searchParams
}: {
  searchParams: Promise<{ mode?: string }>;
}) {
  const user = await requireRole(["applicant"]);
  const params = await searchParams;
  const intakeMode = params.mode === "paper" ? "paper" : params.mode === "digital" ? "digital" : "supporting_documents";
  const { application } = await getLatestApplicantApplication(user.id);
  if (!application) redirect("/applicant/application");
  const documents = await prisma.uploadedDocument.findMany({ where: { applicationId: application.id }, orderBy: { createdAt: "desc" } });
  const processed = documents.filter((doc) => doc.processingStatus === "completed").length;
  const unsorted = documents.filter((doc) => metadata(doc).organizationStatus === "unsorted").length;
  const title = intakeMode === "paper" ? "Upload completed scanned application" : "Upload resume and supporting documents";
  const description = intakeMode === "paper"
    ? "Use this path for completed paper applications. The Document Intake Engine will classify the scanned form, attempt field extraction, and send missing data to HR review."
    : "Upload your resume and application materials. The Document Intake Engine will organize them and guide you through the remaining steps.";

  return (
    <DashboardShell user={user} nav={[
      { href: "/applicant/dashboard", label: "Dashboard" },
      { href: "/applicant/start", label: "Begin Intake" },
      { href: "/applicant/quick-upload", label: "Document Upload" },
      { href: "/applicant/intake-status", label: "Intake Status" },
      { href: "/applicant/application", label: "Application" }
    ]}>
      <div className="grid gap-6">
        <section className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="flex flex-wrap items-start gap-4">
            {intakeMode === "paper" ? <ScanLine className="h-10 w-10 text-orange-600" /> : <FileStack className="h-10 w-10 text-teal-600" />}
            <div>
              <p className="text-sm font-semibold text-orange-600">Document Intake Engine</p>
              <h1 className="mt-2 text-3xl font-semibold">{title}</h1>
              <p className="mt-2 max-w-3xl text-sm text-muted-foreground">{description}</p>
            </div>
          </div>
        </section>
        <div className="grid gap-4 sm:grid-cols-4">
          <OperationalPulse label="Uploaded" value={documents.length} icon="check" color="blue" />
          <OperationalPulse label="Processed" value={processed} icon="care" color="purple" />
          <OperationalPulse label="Pending" value={documents.length - processed} icon="clock" color="orange" />
          <OperationalPulse label="Unsorted" value={unsorted} icon="alert" color="red" />
        </div>
        <QuickCredentialUploadForm intakeMode={intakeMode} />
        <Card>
          <CardHeader><CardTitle>Uploaded Application Materials</CardTitle></CardHeader>
          <CardContent className="grid gap-2 text-sm">
            {documents.map((doc) => {
              const meta = metadata(doc);
              return (
                <div key={doc.id} className="rounded-md border bg-slate-50 p-3">
                  <p className="font-medium">{doc.fileName}</p>
                  <p className="text-muted-foreground">
                    {doc.documentType} - {doc.processingStatus.replace(/_/g, " ")} - suggested {doc.detectedDocumentType?.replace(/_/g, " ") ?? "pending"}
                  </p>
                  {meta.organizationStatus ? <p className="mt-1 text-xs text-orange-700">Organization: {String(meta.organizationStatus).replace(/_/g, " ")}</p> : null}
                </div>
              );
            })}
            {!documents.length ? <p className="text-muted-foreground">No documents uploaded yet.</p> : null}
          </CardContent>
        </Card>
        <div className="flex flex-wrap gap-3">
          <Button asChild variant="outline"><Link href="/applicant/intake-status">View Intake Status</Link></Button>
          <Button asChild><Link href="/applicant/application">Continue Full Application</Link></Button>
        </div>
      </div>
    </DashboardShell>
  );
}
